import random
from dataclasses import dataclass, replace
MIN = 100
BIG = (2**63 - 1) // 4

@dataclass(frozen=True)
class Clip:
    id: str; start: int; sin: int; sout: int; sdur: int = BIG
    @property
    def dur(self): return self.sout - self.sin
    @property
    def end(self): return self.start + self.dur

def split(clips, cid, at):
    c = next(x for x in clips if x.id == cid)
    if at - c.start < MIN or c.end - at < MIN: return None
    ss = c.sin + (at - c.start)
    l = replace(c, id=cid+"L", sout=ss); r = replace(c, id=cid+"R", start=at, sin=ss)
    return [y for x in clips for y in ([l, r] if x.id == cid else [x])]

def clamp(v, lo, hi): return max(lo, min(hi, v))

def trim_start(c, ns):
    lo = max(0, c.start - c.sin); hi = c.end - MIN
    if hi < lo: return c
    s = clamp(ns, lo, hi); d = s - c.start
    return replace(c, start=s, sin=c.sin + d)

def trim_end(c, ne):
    avail = c.sdur - c.sin
    lo = c.start + MIN; hi = c.start + max(avail, MIN)
    e = clamp(ne, lo, hi)
    return replace(c, sout=c.sin + (e - c.start))

def nearest_free(clips, cid, desired):
    c = next(x for x in clips if x.id == cid)
    others = sorted([x for x in clips if x.id != cid], key=lambda x: x.start)
    desired = max(0, desired); best = desired; bd = None
    def consider(gs, ge):
        nonlocal best, bd
        if ge - gs < c.dur: return
        cand = clamp(desired, gs, ge - c.dur); d = abs(cand - desired)
        if bd is None or d < bd: best, bd = cand, d
    gs = 0
    for o in others:
        consider(gs, o.start); gs = max(gs, o.end)
    consider(gs, BIG)
    return best

rnd = random.Random(3); bad = 0
for t in range(5000):
    # non-overlapping lane
    clips, cursor = [], rnd.randint(0, 500)
    for i in range(rnd.randint(1, 6)):
        d = rnd.randint(150, 5000); sin = rnd.randint(0, 3000); sdur = sin + d + rnd.randint(0, 4000)
        clips.append(Clip(f"c{i}", cursor, sin, sin + d, sdur)); cursor += d + rnd.randint(0, 800)
    # --- nearest_free never overlaps and never goes negative
    cid = rnd.choice(clips).id
    s = nearest_free(clips, cid, rnd.randint(-2000, 30000))
    moved = [replace(c, start=s) if c.id == cid else c for c in clips]
    ms = sorted(moved, key=lambda x: x.start)
    ok = s >= 0 and all(a.end <= b.start for a, b in zip(ms, ms[1:]))
    # --- trims stay inside source, keep >= MIN, and pin the opposite edge
    c = rnd.choice(clips)
    a = trim_start(c, rnd.randint(-5000, 20000)); b = trim_end(c, rnd.randint(-5000, 20000))
    ok &= a.end == c.end and a.dur >= MIN and a.sin >= 0 and a.start >= 0 and a.sout <= c.sdur
    ok &= b.start == c.start and b.dur >= MIN and b.sout <= max(c.sdur, c.sin + MIN)
    # --- split preserves footage exactly
    at = rnd.randint(c.start, c.end)
    sp = split(clips, c.id, at)
    if sp is not None:
        l = next(x for x in sp if x.id == c.id + "L"); r = next(x for x in sp if x.id == c.id + "R")
        ok &= l.sin == c.sin and r.sout == c.sout and l.sout == r.sin and l.end == r.start == at and l.dur + r.dur == c.dur
    else:
        ok &= (at - c.start < MIN or c.end - at < MIN)
    if not ok: bad += 1; print("FAIL", t, c, a, b)
print("violations:", bad)
