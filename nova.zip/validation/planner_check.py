import random

def plan(beats, clips, per_cut, start, end, min_cut=400, guard_zero=True):
    if guard_zero: clips = [c for c in clips if c[1] > 0]
    if not clips or end <= start: return []
    inner = [b for b in beats if start < b < end]
    inner = [b for i, b in enumerate(inner) if i % per_cut == 0]
    bounds = [start]
    for b in inner:
        if b - bounds[-1] >= min_cut: bounds.append(b)
    while len(bounds) > 1 and end - bounds[-1] < min_cut: bounds.pop()
    bounds.append(end)
    cursor, rr, out = {}, 0, []
    for i in range(len(bounds) - 1):
        s, e = bounds[i], bounds[i + 1]; dur = e - s
        chosen = None
        for k in range(len(clips)):
            c = clips[(rr + k) % len(clips)]
            if c[1] >= dur:
                chosen = c; rr = (rr + k + 1) % len(clips); break
        if chosen:
            wanted = cursor.get(chosen[0], 0)
            src = wanted if wanted + dur <= chosen[1] else 0
            cursor[chosen[0]] = src + dur
            out.append((chosen[0], s, dur, src))
        else:
            longest = max(clips, key=lambda c: c[1]); t = s
            while t < e:
                d = min(e - t, longest[1]); out.append((longest[0], t, d, 0)); t += d
    return out

rnd = random.Random(7)
bad = 0
for trial in range(3000):
    bpm = rnd.uniform(70, 180); period = 60000 / bpm; first = rnd.uniform(0, period)
    beats = [round(first + k * period) for k in range(400)]
    clips = [(f"c{i}", rnd.choice([0, 300, 900, 2500, 6000, 15000])) for i in range(rnd.randint(1, 6))]
    per = rnd.choice([1, 2, 4, 8])
    start = rnd.randint(0, 3000); end = start + rnd.randint(500, 40000)
    out = plan(beats, clips, per, start, end)
    if not out:
        if any(c[1] > 0 for c in clips) and end > start: bad += 1; print("empty plan", trial)
        continue
    # contiguity + coverage
    ok = out[0][1] == start and abs((out[-1][1] + out[-1][2]) - end) == 0
    for a, b in zip(out, out[1:]):
        ok &= (a[1] + a[2] == b[1])
    # every cut boundary is start/end or a beat (repeat-fill splits are the only exception)
    beatset = set(beats)
    lens = {c[0]: c[1] for c in clips}
    for c in out:
        ok &= (c[3] + c[2] <= lens[c[0]])          # never read past the source
        ok &= c[2] > 0
    if not ok: bad += 1; print("invariant violated", trial)
print("violations:", bad)

# Confirm the zero-length hazard is real without the guard (bounded iterations)
try:
    import signal
    def h(*a): raise TimeoutError
    signal.signal(signal.SIGALRM, h); signal.alarm(2)
    plan([500, 1000, 1500], [("z", 0)], 1, 0, 5000, guard_zero=False)
    print("no hang without guard")
except TimeoutError:
    print("HANG without guard (guard is required)")
