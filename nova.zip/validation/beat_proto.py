import numpy as np, math, random

RATE = 50

def flux_of(peaks):
    f = np.zeros(len(peaks))
    f[1:] = np.maximum(0, np.diff(peaks))
    return f

def estimate_tempo(flux, min_bpm=70, max_bpm=180, prior_bpm=120, prior_sigma_oct=0.9):
    n = len(flux)
    lag_lo = int(math.floor(60 * RATE / max_bpm)) - 1
    lag_hi = int(math.ceil(60 * RATE / min_bpm)) + 1
    ac = {}
    for lag in range(lag_lo - 1, lag_hi + 2):
        ac[lag] = float(np.dot(flux[:n - lag], flux[lag:])) / (n - lag)
    best, best_score = None, -1
    for lag in range(lag_lo, lag_hi + 1):
        bpm = 60 * RATE / lag
        w = math.exp(-0.5 * (math.log2(bpm / prior_bpm) / prior_sigma_oct) ** 2)
        s = ac[lag] * w
        # must be a local max of the raw autocorrelation
        if ac[lag] >= ac[lag - 1] and ac[lag] >= ac[lag + 1] and s > best_score:
            best, best_score = lag, s
    if best is None:
        return None
    a, b, c = ac[best - 1], ac[best], ac[best + 1]
    denom = a - 2 * b + c
    frac = 0.5 * (a - c) / denom if abs(denom) > 1e-12 else 0.0
    lag_f = best + max(-0.5, min(0.5, frac))
    mean_ac = np.mean([ac[l] for l in range(lag_lo, lag_hi + 1)])
    conf = ac[best] / mean_ac if mean_ac > 0 else 0
    return lag_f, conf

def grid_score(flux, period, phase):
    n = len(flux); s = 0.0; k = 0
    x = phase
    while x < n - 1:
        i = int(round(x))
        s += max(flux[max(0, i-1)], flux[i], flux[min(n-1, i+1)]) if False else flux[i]
        x += period; k += 1
    return s / max(1, k)

def fit_grid(flux, period0):
    best = (-1, period0, 0.0)
    for rel in np.arange(-0.02, 0.02001, 0.004):
        p = period0 * (1 + rel)
        steps = int(math.ceil(p * 4))
        for j in range(steps):
            ph = j * p / steps
            sc = grid_score(flux, p, ph)
            if sc > best[0]:
                best = (sc, p, ph)
    return best

def synth(bpm, offset_ms, dur_s=60, seed=0, hat=True):
    rnd = random.Random(seed)
    n = dur_s * RATE
    env = np.zeros(n) + 0.08
    period = 60.0 / bpm
    t = offset_ms / 1000.0
    while t < dur_s:
        i = int(round(t * RATE + rnd.uniform(-0.5, 0.5)))
        amp = rnd.uniform(0.7, 1.0)
        for k in range(8):
            if 0 <= i + k < n:
                env[i + k] = max(env[i + k], amp * math.exp(-k / 2.5))
        if hat:  # off-beat hi-hat, weaker
            h = i + int(round(period * RATE / 2))
            for k in range(3):
                if 0 <= h + k < n:
                    env[h + k] = max(env[h + k], 0.3 * math.exp(-k / 1.5))
        t += period
    env += np.array([rnd.uniform(0, 0.03) for _ in range(n)])
    return np.clip(env, 0, 1)

if __name__ == "__main__":
    ok = True
    for bpm in (90, 100, 110, 120, 126, 128, 140, 150, 174):
        for off in (0, 130, 333, 470):
            peaks = synth(bpm, off, seed=bpm + off)
            fl = flux_of(peaks)
            lag, conf = estimate_tempo(fl)
            sc, p, ph = fit_grid(fl, lag)
            est_bpm = 60 * RATE / p
            phase_ms = ph / RATE * 1000
            beat_ms = 60000 / bpm
            # phase error modulo one beat (pulse rises at index i => flux peak at i)
            err = ((phase_ms - off + beat_ms / 2) % beat_ms) - beat_ms / 2
            good = abs(est_bpm - bpm) / bpm < 0.01 and abs(err) <= 40
            ok &= good
            print(f"bpm {bpm:>3} off {off:>3}: est {est_bpm:6.2f}  phase err {err:6.1f} ms  conf {conf:4.1f} {'OK' if good else 'FAIL'}")
    print("ALL OK" if ok else "SOME FAILED")
