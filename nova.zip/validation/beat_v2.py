import numpy as np, math
from beat_proto import synth, flux_of, estimate_tempo, RATE

def interp(flux, x):
    i = int(math.floor(x)); f = x - i
    if i < 0 or i + 1 >= len(flux): return 0.0
    return flux[i] * (1 - f) + flux[i + 1] * f

def smooth3(flux):
    # tiny [0.25 .5 .25] smoothing so the score surface is gentle around each onset
    s = np.copy(flux)
    s[1:-1] = 0.25 * flux[:-2] + 0.5 * flux[1:-1] + 0.25 * flux[2:]
    return s

def grid_score(sf, period, phase):
    n = len(sf); s = 0.0; k = 0; x = phase
    while x < n - 2:
        s += interp(sf, x); x += period; k += 1
    return s / max(1, k)

def fit_grid(flux, period0, span=0.015, period_step=0.001, phase_div=8):
    sf = smooth3(flux)
    best = (-1, period0, 0.0)
    rel = -span
    while rel <= span + 1e-9:
        p = period0 * (1 + rel)
        steps = int(math.ceil(p * phase_div))
        for j in range(steps):
            ph = j * p / steps
            sc = grid_score(sf, p, ph)
            if sc > best[0]: best = (sc, p, ph)
        rel += period_step
    return best

def beats_from(period, phase, n_frames):
    out = []; x = phase
    while x < n_frames:
        out.append(x / RATE * 1000); x += period
    return out

if __name__ == "__main__":
    fails = 0; worst_all = 0
    for bpm in (90, 100, 110, 120, 126, 128, 140, 150, 174):
        for off in (0, 130, 333, 470):
            peaks = synth(bpm, off, seed=bpm + off)
            fl = flux_of(peaks)
            lag, conf = estimate_tempo(fl)
            sc, p, ph = fit_grid(fl, lag)
            est = beats_from(p, ph, len(fl))
            beat_ms = 60000 / bpm
            truth = [off + k * beat_ms for k in range(-3, int((len(fl) / RATE * 1000 - off) / beat_ms) + 1)]
            # compare by nearest-truth after aligning the grid's beat index (mod one beat)
            errs = []
            for e in est:
                t = min(truth, key=lambda tt: abs(tt - e))
                errs.append(e - t)
            errs = np.array(errs)
            worst = np.max(np.abs(errs)); mean = np.mean(np.abs(errs))
            good = worst <= 45
            fails += (not good); worst_all = max(worst_all, worst)
            print(f"bpm {bpm:>3} off {off:>3}: est {60*RATE/p:6.2f} mean {mean:5.1f} worst {worst:5.1f} ms {'OK' if good else 'FAIL'}")
    print(f"failures: {fails}  worst beat error overall: {worst_all:.1f} ms")
