// A consistent, long-established toolchain set (Kotlin 2.0.21 + matching KSP + Hilt 2.52 + AGP 8.7).
// Newer versions exist; upgrade later with Android Studio's AGP Upgrade Assistant once this builds.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
    id("com.google.dagger.hilt.android") version "2.52" apply false
}
