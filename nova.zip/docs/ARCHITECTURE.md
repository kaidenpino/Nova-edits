> **v0.2 note.** Where this document describes FFmpeg export, a single-player preview or Retrofit, the code now
> differs: export uses Media3 Transformer (video lane + music lane as two sequences), the preview is one master clock
> driving a video player and a music player, music catalogues use OkHttp + loose JSON parsing, and the main video
> lane is *magnetic* (always packed) so preview and export match. The rest of the design stands.

# Nova Editor: Architecture Blueprint

Native Android (Kotlin + Jetpack Compose) video editor. Working name: **Nova**.

---

## 0. Reality check on the "killer feature" (read first)

The music library is the riskiest part of this product, and it is a legal and platform problem before it is a technical one.

| Source | What's actually possible |
|---|---|
| **YouTube Music** | There is **no public API**. YouTube Data API v3 can *search* videos, but its terms forbid separating/downloading audio, and playback must go through the official player. Unofficial extractors (NewPipe-style, yt-dlp) violate YouTube's ToS and Google Play policy and are a common reason apps get removed. Treat YouTube as **not viable as a timeline audio source**. |
| **SoundCloud** | Official API exists (apply for access, OAuth). Search and streaming are supported with attribution, but baking a stream into an exported file is only safe for tracks that are `downloadable` or carry a Creative Commons license. Verify current API terms before shipping. |
| **Exported videos** | Even with a legitimate stream, commercial music in a video posted to TikTok/YouTube/Instagram triggers Content ID claims. CapCut avoids this with a licensed, commercial-safe library. |

**Design consequence:** the app models every source behind a `MusicProvider` interface and tags each track with `ExportRights` (`EXPORT_OK` or `PREVIEW_ONLY`).

- `EXPORT_OK`: downloadable, cached, waveform-analyzed, mixed into export.
- `PREVIEW_ONLY`: streamed for auditioning and placed on the timeline as a reference. On export the user is asked to swap it, or export without it and add the sound inside the destination platform.

Sources that make the feature real: SoundCloud (CC/downloadable subset), Jamendo, Audius, a licensed partner catalog (e.g. Epidemic Sound's partner program), and the user's local files. Check each one's license terms.

---

## 1. Tech stack

| Concern | Choice | Why |
|---|---|---|
| UI | Jetpack Compose + Material 3 | Timeline is custom-drawn (`Canvas`), so Compose gives full control |
| Preview playback | **Media3 ExoPlayer**; `CompositionPlayer` (experimental) for real multi-track preview | Hardware decode, frame-accurate seeks; CompositionPlayer previews the same `Composition` you export |
| Export | **Media3 Transformer** (MediaCodec, hardware) as the primary path | Fast, battery-friendly, no GPL baggage |
| Exotic filters | FFmpeg behind an `FfmpegRunner` interface | **FFmpegKit was archived and its binaries retired in 2025**; use a maintained fork or build your own LGPL FFmpeg. Never hard-wire it. |
| DI | Hilt | Standard, testable |
| Persistence | Room (project metadata) + JSON EDL (edit decision list) | Projects are just references + edit instructions = non-destructive |
| Background export | WorkManager + foreground service | Survives app backgrounding |
| Network | Retrofit + OkHttp + kotlinx.serialization | Interceptors handle OAuth |
| Thumbnails | Coil `VideoFrameDecoder` + on-disk strip cache | |
| Audio analysis | MediaCodec decode, then peaks, then onset detection | No native deps |
| Async | Coroutines + Flow | |

```kotlin
// build.gradle.kts (app), sketch
implementation(platform("androidx.compose:compose-bom:<latest>"))
implementation("androidx.media3:media3-exoplayer:<v>")
implementation("androidx.media3:media3-ui:<v>")
implementation("androidx.media3:media3-transformer:<v>")
implementation("androidx.media3:media3-effect:<v>")
implementation("androidx.media3:media3-datasource-okhttp:<v>")
implementation("com.google.dagger:hilt-android:<v>")
implementation("com.squareup.retrofit2:retrofit:<v>")
implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:<v>")
implementation("io.coil-kt:coil-video:<v>")
```

### Module layout

```
:app                 nav host, DI wiring
:core:model          Clip, Track, Project (pure Kotlin, @Immutable)
:core:timeline       Snapper, EditOps (split/trim/ripple/free-slot), undo stack (pure Kotlin, unit-tested)
:core:beat           BeatAnalyzer, AutoCutPlanner (pure Kotlin, unit-tested)
:core:media          PreviewEngine, ExportEngine, WaveformExtractor, BeatDetector
:feature:editor      EditorScreen, EditorViewModel, Timeline composables
:feature:music       MusicProvider(s), MusicRepository, music browser UI
```

---

## 2. MVVM without dropped frames

**Unidirectional data flow.** `EditorUiState` is a single immutable snapshot. The UI sends intents (`onMoveClip`, `onZoom`); the ViewModel reduces them into a new state.

**Rules that keep the UI at 60/120 fps:**

1. **Separate high-frequency state from structural state.** Playhead position updates every ~16 ms. It lives in `PreviewEngine.positionMs` (a `StateFlow`), *not* in `EditorUiState`. Only a tiny `TimeReadout` composable collects it; the timeline consumes it in a `LaunchedEffect` that drives the scroll state. Result: the tracks never recompose during playback.
2. **Heavy work never touches the main thread.** Decoding, waveform extraction, thumbnail strips, beat detection, and export all run on `Dispatchers.Default`/`IO` and publish results via Flow.
3. **Draw, don't compose, the dense stuff.** Waveforms, ruler ticks, and beat markers are `Canvas` draws. A 3-minute song is one draw call with no per-bar composables.
4. **Downsample to the pixel grid.** Waveform peaks are stored at 50/s; the drawer collapses them to at most one column per pixel, so zooming out stays cheap.
5. **Stability.** Model classes are `@Immutable`; large lists can use `kotlinx.collections.immutable`; lambdas passed down are remembered or use `rememberUpdatedState`.
6. **Local gesture state.** While dragging a clip, the offset lives in local `remember` state (no ViewModel round trip per pointer event). It commits once on drag end.
7. **Proxy media.** For 4K/HEVC sources, generate a 540p all-intra proxy in the background; scrubbing uses the proxy, export uses the original.
8. **Baseline Profiles + Macrobenchmark** for the editor screen; check jank in CI.

**Non-destructive editing:** a `Clip` stores `sourceUri`, `sourceInMs`, `sourceOutMs`, and `timelineStartMs`. Nothing is ever re-encoded until export. Undo/redo is a stack of immutable state snapshots (or commands, if memory becomes an issue).

---

## 3. Music integration strategy

```
UI (search box)
   -> MusicViewModel
       -> MusicRepository
            |- search():   fan out to all MusicProviders in parallel, emit results progressively
            |- preview():  stream via ExoPlayer + SimpleCache (auditioning only)
            \- cacheForTimeline(): only if EXPORT_OK
                   download -> atomic rename -> extract waveform peaks -> detect beats
```

- **Provider interface** hides each API's quirks (auth, pagination, stream formats).
- **Progressive results:** the first provider to answer paints the list immediately.
- **Two caches:** ExoPlayer's `SimpleCache` for preview streams (LRU, size-capped); a `filesDir/music/` folder for timeline assets (keyed by `provider_id`, `.part` file renamed atomically on completion).
- **Secrets:** never ship client secrets in the APK. Put the OAuth token exchange behind a small backend and give the app short-lived tokens.
- **Attribution:** required by SoundCloud and CC licenses. Show artist/title/link in the picker and in the export credits.

See `MusicRepository.kt`.

---

## 4. Rendering / export

Two paths behind one `ExportEngine` interface:

1. **Media3 Transformer (default).** Build a `Composition` of `EditedMediaItemSequence`s (one for the video track, one for audio). Clip trims use `MediaItem.ClippingConfiguration`. Audio fades need a small custom `AudioProcessor` that applies a gain ramp. The Transformer API surface changes between releases, so pin a version and check its docs.
2. **FFmpeg (fallback for unusual filters).** Deterministic command-line, easy to reason about, and useful for advanced transitions (`xfade`) or LUT filters.

`ExportEngine.kt` contains an FFmpeg command builder for: video clip + music track, video fade in/out, music fade in/out, optional ducking of the music under original audio.

---

## 5. AI beat-sync (v2, implemented in `BeatEngine.kt`)

v1 flagged individual onsets, which misses beats in quiet passages and fires on hi-hats. **v2 fits a grid instead:**

1. Onset flux from the 50 Hz amplitude envelope.
2. Autocorrelation over lags for 70-180 BPM, with a log-Gaussian tempo prior so half/double-time is not chosen by mistake, then parabolic interpolation for a fractional lag.
3. Global grid fit (period +-1.5%, phase in 1/8-frame steps, linear interpolation) so long songs do not drift.
4. A beat at **every grid position**, including ones the music skips, each with a strength value.

`AutoCutPlanner` then turns a grid plus a pile of clips into a gap-free, beat-locked edit (cut every beat / 2 beats / bar / 2 bars). Clips that are too short are skipped, reused clips continue where they left off, and zero-length clips are ignored.

**Verified so far:** on synthetic kick + hi-hat tracks (90-174 BPM, jittered onsets) tempo is within 0.3% and the worst beat error is 19.5 ms across 36 cases. The planner and edit operations held their invariants over thousands of randomized cases (Python ports in `validation/`). **Not yet verified:** real music, and the Kotlin itself has not been compiled here.

**Next (v3):** per-band STFT spectral flux (kick vs. snare vs. hats), a tempo tracker for songs with tempo changes, and calibrating `confidence` on a real-music corpus before the UI says "beat-synced".

---

## 6. CapCut pain points -> how this design answers them

| Pain point | Approach |
|---|---|
| Ads / bloat | No ad SDKs; feature modules are separate |
| Forced watermark | The export pipeline has no overlay stage |
| Destructive edits | Edit decision list referencing untouched sources |
| Timeline zoom/snap | Pinch zoom with the playhead as anchor; zoom-aware snap threshold (fixed on-screen distance, not fixed time); trim handles, split, ripple delete; video clips can never overlap |
| Music access | Provider abstraction plus honest per-track export rights |

---

## 7. Suggested build order

1. `:core:model` + `:core:timeline` (pure Kotlin, unit tests for snapping and edits)
2. Editor screen with a single-track preview
3. Waveform + audio track
4. Export via Transformer
5. Music providers (start with local files + one licensed source)
6. Beat-sync v1, then multi-track preview via CompositionPlayer
7. Proxies, thumbnails, effects, text
