package com.nova

import com.nova.beat.AutoCutPlanner
import com.nova.beat.BeatAnalyzer
import com.nova.beat.CutRhythm
import com.nova.beat.SourceClip
import com.nova.editor.Clip
import com.nova.editor.EditOps
import com.nova.editor.PreviewClip
import com.nova.editor.PreviewMap
import com.nova.editor.Snapper
import com.nova.editor.Track
import com.nova.editor.TrackType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

/*
 * Put in app/src/test/java/com/nova/ and run with `./gradlew test`.
 * These encode the same invariants I checked with randomized Python ports of the algorithms
 * (tempo/grid fit, planner, edit ops). The Kotlin itself had NOT been compiled or run when written.
 */

class BeatAnalyzerTest {

    /** Kick on every beat (with jitter) plus a weaker off-beat hi-hat, at the 50 Hz envelope rate. */
    private fun synth(bpm: Double, offsetMs: Double, seconds: Int = 60, seed: Long = 1): FloatArray {
        val rnd = java.util.Random(seed)
        val n = seconds * 50
        val env = FloatArray(n) { 0.08f + rnd.nextFloat() * 0.03f }
        val period = 60.0 / bpm
        var t = offsetMs / 1000.0
        while (t < seconds) {
            val i = (t * 50 + rnd.nextDouble() - 0.5).roundToInt()
            val amp = 0.7f + rnd.nextFloat() * 0.3f
            for (k in 0 until 8) if (i + k in 0 until n) env[i + k] = max(env[i + k], amp * exp(-k / 2.5).toFloat())
            val h = i + (period * 50 / 2).roundToInt()
            for (k in 0 until 3) if (h + k in 0 until n) env[h + k] = max(env[h + k], 0.3f * exp(-k / 1.5).toFloat())
            t += period
        }
        return env
    }

    @Test fun findsTempoAndPlacesBeatsOnTheKicks() {
        for (bpm in listOf(90.0, 120.0, 128.0, 140.0, 174.0)) {
            for (offset in listOf(0.0, 333.0, 470.0)) {
                val maybeGrid = BeatAnalyzer.analyze(synth(bpm, offset))
                assertNotNull("no grid for $bpm BPM", maybeGrid)
                val grid = maybeGrid!!
                assertTrue("bpm $bpm got ${grid.bpm}", abs(grid.bpm - bpm) / bpm < 0.01)

                val beatMs = 60_000.0 / bpm
                for (b in grid.beatsMs) {
                    // distance to the nearest true kick (the grid may extrapolate a few beats before the first one)
                    val k = Math.round((b - offset) / beatMs)
                    val truth = offset + k * beatMs
                    assertTrue("bpm $bpm off $offset beat $b vs $truth", abs(b - truth) <= 45)
                }
            }
        }
    }

    @Test fun tooShortOrFlatInputGivesNoGrid() {
        assertNull(BeatAnalyzer.analyze(FloatArray(50)))                    // 1 second
        assertNull(BeatAnalyzer.analyze(FloatArray(50 * 30) { 0.2f }))      // 30 s of constant level
    }

    @Test fun nearestBeatSnapsToTheClosestGridPoint() {
        val grid = BeatAnalyzer.analyze(synth(120.0, 0.0))!!
        val near = grid.nearestBeat(1_260)!!
        assertTrue(abs(near - 1_260) <= grid.periodMs / 2 + 1)
    }
}

class AutoCutPlannerTest {
    private val grid = BeatAnalyzer.analyze(FloatArray(50 * 60).also { env ->
        // clean 120 BPM kicks: one every 25 frames
        for (i in env.indices) env[i] = if (i % 25 < 3) 1f else 0.1f
    })!!

    private val clips = listOf(
        SourceClip("a", "uri://a", 12_000),
        SourceClip("b", "uri://b", 900),      // too short for most segments
        SourceClip("z", "uri://z", 0),        // must be ignored, not loop forever
    )

    @Test fun coversTheRangeWithoutGapsOrOverlaps() {
        val cuts = AutoCutPlanner.plan(grid, clips, CutRhythm.EVERY_BAR, startMs = 500, endMs = 20_000)
        assertEquals(500L, cuts.first().timelineStartMs)
        assertEquals(20_000L, cuts.last().timelineStartMs + cuts.last().durationMs)
        cuts.zipWithNext().forEach { (x, y) -> assertEquals(x.timelineStartMs + x.durationMs, y.timelineStartMs) }
    }

    @Test fun neverReadsPastTheEndOfASource() {
        val cuts = AutoCutPlanner.plan(grid, clips, CutRhythm.EVERY_2_BEATS, 0, 30_000)
        val lengths = clips.associate { it.id to it.durationMs }
        cuts.forEach { assertTrue(it.sourceInMs + it.durationMs <= lengths.getValue(it.clipId)) }
        assertTrue(cuts.none { it.clipId == "z" })
    }

    @Test fun interiorCutsLandOnBeats() {
        val cuts = AutoCutPlanner.plan(grid, listOf(SourceClip("a", "u", 60_000)), CutRhythm.EVERY_BEAT, 0, 10_000)
        cuts.drop(1).forEach { cut ->
            assertTrue(grid.beatsMs.any { abs(it - cut.timelineStartMs) <= 1 })
        }
    }

    @Test fun plainBeatListOverloadMatchesTheGridOverload() {
        val viaGrid = AutoCutPlanner.plan(grid, clips, CutRhythm.EVERY_BAR, 0, 20_000)
        val viaList = AutoCutPlanner.plan(grid.beatsMs, clips, CutRhythm.EVERY_BAR, 0, 20_000)
        assertEquals(viaGrid, viaList)
    }
}

class EditOpsTest {
    private fun clip(id: String, start: Long, inMs: Long, outMs: Long, sourceDur: Long = 60_000) =
        Clip(id, id, "uri://$id", start, inMs, outMs, sourceDurationMs = sourceDur)

    private fun lane(vararg c: Clip, type: TrackType = TrackType.VIDEO) = Track("v", type, c.toList())

    @Test fun splitKeepsTheSameFootage() {
        val t = EditOps.split(lane(clip("c", 1_000, 500, 6_500)), "c", 3_000, "L", "R")!!
        val (l, r) = t.clips
        assertEquals(500L, l.sourceInMs); assertEquals(2_500L, l.sourceOutMs)     // 2 s of footage
        assertEquals(2_500L, r.sourceInMs); assertEquals(6_500L, r.sourceOutMs)
        assertEquals(3_000L, r.timelineStartMs)
        assertEquals(l.timelineEndMs, r.timelineStartMs)
    }

    @Test fun splitRefusesSlivers() {
        assertNull(EditOps.split(lane(clip("c", 0, 0, 5_000)), "c", 50, "L", "R"))
        assertNull(EditOps.split(lane(clip("c", 0, 0, 5_000)), "c", 4_950, "L", "R"))
    }

    @Test fun trimStartKeepsTheEndFixedAndStaysInsideTheSource() {
        val c = clip("c", 2_000, 1_000, 5_000)
        val shorter = EditOps.trimStart(c, 3_000)
        assertEquals(c.timelineEndMs, shorter.timelineEndMs); assertEquals(2_000L, shorter.sourceInMs)
        val longest = EditOps.trimStart(c, 0)                    // only 1 s of source before the in-point
        assertEquals(1_000L, longest.timelineStartMs); assertEquals(0L, longest.sourceInMs)
    }

    @Test fun trimEndCannotRunPastTheSource() {
        val c = clip("c", 0, 0, 4_000, sourceDur = 6_000)
        assertEquals(6_000L, EditOps.trimEnd(c, 99_000).sourceOutMs)
        assertEquals(EditOps.MIN_CLIP_MS, EditOps.trimEnd(c, -5).durationMs)
    }

    @Test fun rippleDeleteClosesTheGap() {
        val t = EditOps.delete(lane(clip("a", 0, 0, 1_000), clip("b", 1_000, 0, 2_000), clip("c", 3_000, 0, 500)), "b", ripple = true)
        assertEquals(listOf(0L, 1_000L), t.clips.map { it.timelineStartMs })
    }

    @Test fun musicLaneDropOntoAnotherSongSnapsToTheNearestFreeSlot() {
        val t = lane(clip("a", 0, 0, 4_000), clip("b", 4_000, 0, 2_000), clip("m", 10_000, 0, 3_000), type = TrackType.AUDIO)
        val s = EditOps.nearestFreeStart(t, "m", desiredStartMs = 5_000)     // lands inside b
        val others = t.clips.filter { it.id != "m" }
        assertTrue(others.none { s < it.timelineEndMs && s + 3_000 > it.timelineStartMs })
    }

    @Test fun packClosesEveryGapAndKeepsOrder() {
        val packed = EditOps.pack(lane(clip("b", 5_000, 0, 2_000), clip("a", 100, 0, 1_000), clip("c", 9_000, 0, 500)))
        assertEquals(listOf("a", "b", "c"), packed.clips.map { it.id })
        assertEquals(listOf(0L, 1_000L, 3_000L), packed.clips.map { it.timelineStartMs })
    }

    @Test fun reorderMovesTheDraggedClipToWhereItWasDropped() {
        val t = lane(clip("a", 0, 0, 2_000), clip("b", 2_000, 0, 2_000), clip("c", 4_000, 0, 2_000))
        val moved = EditOps.reorder(t, "a", desiredStartMs = 4_500)           // dropped past c's centre
        assertEquals(listOf("b", "c", "a"), moved.clips.map { it.id })
        assertEquals(listOf(0L, 2_000L, 4_000L), moved.clips.map { it.timelineStartMs })
    }

    @Test fun snapperSnapsEitherEdgeWithinTheThreshold() {
        assertEquals(1_000L, Snapper.snap(startMs = 1_040, durationMs = 500, targets = listOf(1_000), thresholdMs = 100))
        assertEquals(1_500L, Snapper.snap(startMs = 1_460, durationMs = 500, targets = listOf(2_000), thresholdMs = 100))   // end edge (1_960) snaps to 2_000
        assertEquals(5_000L, Snapper.snap(startMs = 5_000, durationMs = 500, targets = listOf(1_000), thresholdMs = 100))   // nothing near
    }
}

class PreviewMapTest {
    // a: timeline 0-4000 (4 s of footage); gap 4000-6000; b: timeline 6000-8000 (source 1000-3000)
    private val clips = listOf(
        PreviewClip("a", timelineStartMs = 0, sourceInMs = 0, sourceOutMs = 4_000),
        PreviewClip("b", timelineStartMs = 6_000, sourceInMs = 1_000, sourceOutMs = 3_000),
    )

    @Test fun insideAClipMapsToThatClipAndOffset() {
        assertEquals(0 to 1_000L, PreviewMap.locate(clips, 1_000))
        assertEquals(1 to 1_000L, PreviewMap.locate(clips, 7_000))
    }

    @Test fun aGapOrTheEndHasNoClip() {
        assertNull(PreviewMap.locate(clips, 4_500))        // gap: the player holds still
        assertNull(PreviewMap.locate(clips, 4_000))        // a clip's end is exclusive
        assertNull(PreviewMap.locate(clips, 8_000))
        assertNull(PreviewMap.locate(emptyList(), 0))
    }
}
