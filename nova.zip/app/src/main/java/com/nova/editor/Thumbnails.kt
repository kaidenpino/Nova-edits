package com.nova.editor

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nova.ui.NovaColors
import kotlin.math.ceil
import kotlin.math.max
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Small decoded video frames, cached by (file, half-second bucket) so scrolling, zooming and trimming
 * reuse frames instead of decoding again. 24 MB cap; least-recently-used frames are dropped first.
 */
object ThumbnailCache {
    private const val FRAME_HEIGHT_PX = 120
    private const val BUCKET_MS = 500L

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    suspend fun frame(context: Context, uri: String, timeMs: Long): Bitmap? {
        val bucket = (max(0L, timeMs) / BUCKET_MS) * BUCKET_MS
        val key = "$uri#$bucket"
        cache.get(key)?.let { return it }

        return withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(uri))
                val raw = retriever.getFrameAtTime(bucket * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: return@withContext null
                val width = max(1, raw.width * FRAME_HEIGHT_PX / max(1, raw.height))
                val scaled = Bitmap.createScaledBitmap(raw, width, FRAME_HEIGHT_PX, true)
                if (scaled !== raw) raw.recycle()
                cache.put(key, scaled)
                scaled
            } catch (e: Exception) {
                null                      // unreadable frame: the tile just stays a flat colour
            } finally {
                retriever.release()
            }
        }
    }
}

/**
 * A row of video frames filling the clip. Tile times follow a fixed grid (one tile = [tileWidth] of
 * screen = a fixed number of milliseconds at the current zoom), so trimming a clip does not reshuffle
 * which frames are requested.
 */
@Composable
fun ThumbnailStrip(
    uri: String,
    sourceInMs: Long,
    pixelsPerSecond: Float,
    modifier: Modifier = Modifier,
    tileWidth: Dp = 56.dp,
) {
    val context = LocalContext.current
    val tileMs = max(100L, (tileWidth.value / pixelsPerSecond * 1000f).toLong())

    BoxWithConstraints(modifier) {
        val tiles = ceil(maxWidth / tileWidth).toInt().coerceIn(1, 80)
        Row(Modifier.fillMaxSize()) {
            for (i in 0 until tiles) {
                key(i) {
                    val timeMs = sourceInMs + i * tileMs + tileMs / 2
                    val bitmap by produceState<Bitmap?>(initialValue = null, uri, timeMs) {
                        value = ThumbnailCache.frame(context, uri, timeMs)
                    }
                    Box(
                        Modifier
                            .width(tileWidth)
                            .fillMaxHeight()
                            .background(NovaColors.VideoClip)
                    ) {
                        val frame = bitmap
                        if (frame != null) {
                            Image(
                                bitmap = frame.asImageBitmap(),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                }
            }
        }
    }
}
