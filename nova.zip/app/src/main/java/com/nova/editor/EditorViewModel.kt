package com.nova.editor

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.beat.AutoCutPlanner
import com.nova.beat.CutRhythm
import com.nova.beat.SourceClip
import com.nova.export.NovaExporter
import com.nova.music.LocalAudio
import com.nova.music.PEAKS_PER_SEC
import com.nova.music.ProviderId
import com.nova.music.creditLine
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Holds the project. Every change to the timeline goes through [edit], the single choke point that
 *   - makes the undo snapshot,
 *   - drops a stale selection,
 *   - recomputes the beat markers.
 * The main video lane is kept packed (no gaps) by the individual operations via [normalized].
 */
@HiltViewModel
class EditorViewModel @Inject constructor(
    val preview: PreviewEngine,
    private val exporter: NovaExporter,
) : ViewModel() {

    private val _state = MutableStateFlow(
        EditorUiState(
            tracks = listOf(
                Track("v1", TrackType.VIDEO, emptyList()),
                Track("a1", TrackType.AUDIO, emptyList()),
            )
        )
    )
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    private val undoStack = ArrayDeque<EditorUiState>()

    init {
        // Keep both preview playlists in sync with the lanes after EVERY edit (import, move, trim,
        // split, delete, undo...). The engine preserves the playhead.
        viewModelScope.launch {
            state.map { previewClips(it, TrackType.VIDEO) }.distinctUntilChanged()
                .collect { preview.setVideoClips(it) }
        }
        viewModelScope.launch {
            state.map { previewClips(it, TrackType.AUDIO) }.distinctUntilChanged()
                .collect { preview.setAudioClips(it) }
        }
    }

    /* ------------------------------ plumbing ------------------------------ */

    /**
     * [transform] returns the new tracks, or null to refuse the edit (nothing changes, no undo entry).
     * [selectClipId] optionally selects a clip as part of the edit.
     */
    private fun edit(selectClipId: String? = null, transform: (List<Track>) -> List<Track>?) {
        val before = _state.value
        val newTracks = transform(before.tracks) ?: return
        if (newTracks == before.tracks) return

        undoStack.addLast(before)
        if (undoStack.size > 100) undoStack.removeFirst()

        val wanted = selectClipId ?: before.selectedClipId
        val selected = wanted?.takeIf { id -> newTracks.any { t -> t.clips.any { it.id == id } } }
        _state.value = before.copy(
            tracks = newTracks,
            selectedClipId = selected,
            canUndo = true,
            beatMarkersMs = beatMarkers(newTracks),
        )
    }

    private fun List<Track>.mapLane(type: TrackType, f: (Track) -> Track): List<Track> =
        map { if (it.type == type) f(it) else it }

    /** Applies [f] to the track that owns [clipId]; null if the clip or the edit doesn't exist. */
    private fun List<Track>.mapOwner(clipId: String, f: (Track) -> Track?): List<Track>? {
        val owner = firstOrNull { t -> t.clips.any { it.id == clipId } } ?: return null
        val updated = f(owner) ?: return null
        return map { if (it.id == owner.id) updated else it }
    }

    private fun Track.normalized(): Track = if (type == TrackType.VIDEO) EditOps.pack(this) else this

    private fun say(text: String) = _state.update { it.copy(message = text) }

    /* ------------------------------ view state ------------------------------ */

    fun onZoom(factor: Float) = _state.update {
        it.copy(pixelsPerSecond = (it.pixelsPerSecond * factor).coerceIn(10f, 800f))
    }

    fun onSeek(ms: Long) = preview.seekTo(ms.coerceAtLeast(0L))

    fun onTogglePlay() = if (preview.isPlaying.value) preview.pause() else preview.play()

    fun onSelect(clipId: String?) = _state.update { it.copy(selectedClipId = clipId) }

    fun onMessageShown() = _state.update { it.copy(message = null) }

    fun undo() {
        val previous = undoStack.removeLastOrNull() ?: return
        val current = _state.value
        _state.value = previous.copy(
            pixelsPerSecond = current.pixelsPerSecond,     // undo edits, not the zoom level
            canUndo = undoStack.isNotEmpty(),
            message = null,
            export = current.export,
        )
    }

    /* ------------------------------ editing ------------------------------ */

    /**
     * While dragging: where would this clip land? The video lane is magnetic (it reorders on release),
     * so it does not snap. The music lane snaps to the playhead and to video clip / music clip edges.
     */
    fun snapPreview(clipId: String, candidateStartMs: Long): Long {
        val s = _state.value
        val track = s.tracks.firstOrNull { t -> t.clips.any { it.id == clipId } } ?: return candidateStartMs
        if (track.type == TrackType.VIDEO) return candidateStartMs.coerceAtLeast(0L)

        val clip = track.clips.first { it.id == clipId }
        val targets = buildList {
            add(preview.positionMs.value)
            s.videoClips.forEach { add(it.timelineStartMs); add(it.timelineEndMs) }
            track.clips.filter { it.id != clipId }.forEach { add(it.timelineStartMs); add(it.timelineEndMs) }
        }
        val thresholdMs = (SNAP_DP / s.pixelsPerSecond * 1000f).toLong()   // ~8dp on screen at any zoom
        return Snapper.snap(candidateStartMs.coerceAtLeast(0L), clip.durationMs, targets, thresholdMs)
    }

    fun onMoveClip(clipId: String, newStartMs: Long) = edit { tracks ->
        tracks.mapOwner(clipId) { track ->
            if (track.type == TrackType.VIDEO) {
                EditOps.reorder(track, clipId, newStartMs)
            } else {
                val start = EditOps.nearestFreeStart(track, clipId, newStartMs)
                track.copy(clips = track.clips.map { if (it.id == clipId) it.copy(timelineStartMs = start) else it })
            }
        }
    }

    /** Committed once when a trim-handle drag ends (live feedback is drawn locally). */
    fun onTrim(clipId: String, edge: TrimEdge, timelineMs: Long) = edit { tracks ->
        tracks.mapOwner(clipId) { track ->
            track.copy(clips = track.clips.map { if (it.id == clipId) EditOps.trim(it, edge, timelineMs) else it }).normalized()
        }
    }

    /** Splits the selected clip (or the first clip under the playhead) at the playhead. */
    fun onSplitAtPlayhead() {
        val at = preview.positionMs.value
        val s = _state.value
        val underPlayhead = s.tracks.flatMap { it.clips }.filter { at > it.timelineStartMs && at < it.timelineEndMs }
        val target = underPlayhead.firstOrNull { it.id == s.selectedClipId } ?: underPlayhead.firstOrNull()
        if (target == null) { say("Move the playhead over a clip to split it."); return }
        val rightId = UUID.randomUUID().toString()
        // The left half keeps the original id, so the selection stays valid.
        edit { tracks ->
            tracks.mapOwner(target.id) { EditOps.split(it, target.id, at, target.id, rightId)?.normalized() }
        }
    }

    /** Ripple-deletes on the video lane (closes the gap); leaves a gap on the music lane. */
    fun onDeleteSelected() {
        val id = _state.value.selectedClipId ?: return
        edit { tracks -> tracks.mapOwner(id) { EditOps.delete(it, id, ripple = it.type == TrackType.VIDEO).normalized() } }
    }

    /* ------------------------------ importing ------------------------------ */

    private data class VideoMeta(val label: String, val durationMs: Long, val width: Int, val height: Int)

    /** Blocking (disk/IO): call from Dispatchers.IO. Returns null if the file can't be read as video. */
    private fun readVideoMeta(context: Context, uri: Uri): VideoMeta? {
        val retriever = MediaMetadataRetriever()
        val info: Triple<Long, Int, Int>? = try {
            retriever.setDataSource(context, uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (duration == null || duration <= 0L) null
            else if (rotation == 90 || rotation == 270) Triple(duration, h, w)     // phones often store portrait video rotated
            else Triple(duration, w, h)
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
        if (info == null) return null

        val name = runCatching {
            context.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull()
        return VideoMeta(label = name ?: "Video", durationMs = info.first, width = info.second, height = info.third)
    }

    /** Called with the Photo Picker's result: reads the length off the main thread, then appends the clip. */
    fun onVideoPicked(context: Context, uri: Uri) {
        viewModelScope.launch {
            val meta = withContext(Dispatchers.IO) { readVideoMeta(context, uri) }
            if (meta == null) { say("Couldn't read that video."); return@launch }
            val clip = Clip(
                id = UUID.randomUUID().toString(),
                label = meta.label,
                sourceUri = uri.toString(),
                timelineStartMs = Long.MAX_VALUE / 8,        // sorts last; pack() then butts it after the others
                sourceInMs = 0L,
                sourceOutMs = meta.durationMs,
                sourceDurationMs = meta.durationMs,
                videoWidth = meta.width,
                videoHeight = meta.height,
            )
            edit(selectClipId = clip.id) { tracks ->
                tracks.mapLane(TrackType.VIDEO) { EditOps.pack(it.copy(clips = it.clips + clip)) }
            }
        }
    }

    /** A song is ready on disk (downloaded or imported): drop it on the music lane at the playhead. */
    fun onMusicReady(audio: LocalAudio) {
        val track = audio.track
        val durationMs = audio.peaks.size * 1000L / PEAKS_PER_SEC
        val id = UUID.randomUUID().toString()
        val clip = Clip(
            id = id,
            label = track.title,
            sourceUri = Uri.fromFile(audio.file).toString(),
            timelineStartMs = 0L,
            sourceInMs = 0L,
            sourceOutMs = durationMs,
            sourceDurationMs = durationMs,
            peaks = audio.peaks,
            beatsMs = audio.beatsMs,
            credit = if (track.provider == ProviderId.LOCAL) null else track.creditLine(),
        )
        val wantedStart = preview.positionMs.value
        edit(selectClipId = id) { tracks ->
            tracks.mapLane(TrackType.AUDIO) { lane ->
                val withClip = lane.copy(clips = lane.clips + clip.copy(timelineStartMs = wantedStart))
                val start = EditOps.nearestFreeStart(withClip, id, wantedStart)     // never overlap another song
                withClip.copy(clips = withClip.clips.map { if (it.id == id) it.copy(timelineStartMs = start) else it })
            }
        }
        say(if (audio.grid != null) "Added ${track.title} (${audio.grid.bpm.toInt()} BPM)" else "Added ${track.title}")
    }

    /* ------------------------------ beat sync ------------------------------ */

    /**
     * The headline feature: re-cut the video lane so every cut lands on a beat of the first song that has
     * a beat grid. Uses the current video clips as the footage pool. Undo restores the original edit.
     */
    fun onBeatSync(rhythm: CutRhythm) {
        val s = _state.value
        val song = s.audioClips.firstOrNull { it.beatsMs.isNotEmpty() }
        val sources = s.videoClips.sortedBy { it.timelineStartMs }
        if (song == null || sources.isEmpty()) { say("Add a video and a song first."); return }

        val beats = song.beatsMs
            .filter { it in song.sourceInMs..song.sourceOutMs }
            .map { song.timelineStartMs + it - song.sourceInMs }
        val cuts = AutoCutPlanner.plan(
            beatsMs = beats,
            allClips = sources.map { SourceClip(it.id, it.sourceUri, it.durationMs) },
            rhythm = rhythm,
            startMs = 0L,
            endMs = song.timelineEndMs,
        )
        if (cuts.isEmpty()) { say("Couldn't find enough beats to cut on."); return }

        val byId = sources.associateBy { it.id }
        val newClips = cuts.map { cut ->
            val src = byId.getValue(cut.clipId)
            val sourceIn = src.sourceInMs + cut.sourceInMs
            src.copy(
                id = UUID.randomUUID().toString(),
                timelineStartMs = cut.timelineStartMs,
                sourceInMs = sourceIn,
                sourceOutMs = sourceIn + cut.durationMs,
            )
        }
        edit { tracks -> tracks.mapLane(TrackType.VIDEO) { EditOps.pack(it.copy(clips = newClips)) } }
        say("Cut to the beat: ${newClips.size} cuts")
    }

    /* ------------------------------ export ------------------------------ */

    fun onExport() {
        val s = _state.value
        val videos = s.videoClips.sortedBy { it.timelineStartMs }
        if (videos.isEmpty()) { say("Add a video first."); return }
        val audios = s.audioClips.sortedBy { it.timelineStartMs }
        val credits = audios.mapNotNull { it.credit }.distinct().joinToString("\n").ifBlank { null }

        preview.pause()
        _state.update { it.copy(export = ExportState.Running(0f)) }
        exporter.start(
            videos = videos,
            audios = audios,
            onProgress = { p ->
                _state.update { st -> if (st.export is ExportState.Running) st.copy(export = ExportState.Running(p)) else st }
            },
            onResult = { result ->
                val next = result.fold(
                    onSuccess = { savedAs -> ExportState.Done(savedAs, credits) },
                    onFailure = { error -> ExportState.Failed(error.message?.take(300) ?: error.javaClass.simpleName) },
                )
                _state.update { it.copy(export = next) }
            },
        )
    }

    fun cancelExport() {
        exporter.cancel()
        _state.update { it.copy(export = ExportState.Idle) }
    }

    fun dismissExport() = _state.update { it.copy(export = ExportState.Idle) }

    override fun onCleared() {
        exporter.cancel()
        preview.release()
    }

    private companion object {
        const val SNAP_DP = 8f
    }
}

private fun previewClips(state: EditorUiState, type: TrackType): List<PreviewClip> =
    state.tracks
        .filter { it.type == type }
        .flatMap { it.clips }
        .sortedBy { it.timelineStartMs }
        .map { PreviewClip(it.sourceUri, it.timelineStartMs, it.sourceInMs, it.sourceOutMs) }

/** Timeline positions of every beat of every music clip, within the part of the song actually used. */
private fun beatMarkers(tracks: List<Track>): List<Long> =
    tracks.filter { it.type == TrackType.AUDIO }
        .flatMap { it.clips }
        .flatMap { c ->
            c.beatsMs
                .filter { it >= c.sourceInMs && it <= c.sourceOutMs }
                .map { c.timelineStartMs + it - c.sourceInMs }
        }
        .sorted()
