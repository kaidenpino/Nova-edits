package com.nova.editor

import androidx.compose.runtime.Immutable

enum class TrackType { VIDEO, AUDIO }

/**
 * One piece of media on the timeline. NON-DESTRUCTIVE: a clip only *references* a source file and a
 * trim range inside it; nothing is re-encoded until export.
 */
@Immutable
data class Clip(
    val id: String,
    val label: String,
    val sourceUri: String,
    val timelineStartMs: Long,      // where the clip sits on the timeline
    val sourceInMs: Long,           // trim in-point inside the source
    val sourceOutMs: Long,          // trim out-point inside the source
    // Full length of the source; caps how far the out-point can be dragged. The default ("unknown") is
    // large but overflow-safe. Set the real value when importing media.
    val sourceDurationMs: Long = UNKNOWN_DURATION,
    val peaks: FloatArray? = null,  // audio only: waveform, PEAKS_PER_SEC per second. Compared by reference.
    val beatsMs: List<Long> = emptyList(), // audio only: beat times inside the SOURCE file
    val credit: String? = null,     // attribution line for the export description (music from catalogues)
    val videoWidth: Int = 0,        // video only, rotation already applied; 0 = unknown
    val videoHeight: Int = 0,
) {
    val durationMs: Long get() = sourceOutMs - sourceInMs
    val timelineEndMs: Long get() = timelineStartMs + durationMs

    companion object {
        const val UNKNOWN_DURATION = Long.MAX_VALUE / 4
    }
}

@Immutable
data class Track(val id: String, val type: TrackType, val clips: List<Clip>)

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val savedAs: String, val credits: String?) : ExportState
    data class Failed(val reason: String) : ExportState
}

@Immutable
data class EditorUiState(
    val tracks: List<Track> = emptyList(),
    val pixelsPerSecond: Float = 80f,            // dp per second: the zoom level
    val beatMarkersMs: List<Long> = emptyList(), // timeline positions of every beat of every music clip
    val selectedClipId: String? = null,
    val canUndo: Boolean = false,
    val message: String? = null,                 // one-shot notice shown as a snackbar, then cleared
    val export: ExportState = ExportState.Idle,
) {
    val durationMs: Long
        get() = tracks.flatMap { it.clips }.maxOfOrNull { it.timelineEndMs } ?: 0L

    val videoClips: List<Clip>
        get() = tracks.filter { it.type == TrackType.VIDEO }.flatMap { it.clips }

    val audioClips: List<Clip>
        get() = tracks.filter { it.type == TrackType.AUDIO }.flatMap { it.clips }
}
