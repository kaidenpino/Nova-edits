package com.nova.editor

import android.content.Context
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.max
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

interface PreviewEngine {
    /** The player whose picture goes on screen. */
    val videoPlayer: Player
    /** Playhead in TIMELINE time. */
    val positionMs: StateFlow<Long>
    val isPlaying: StateFlow<Boolean>
    /** Replace the video lane's clips (sorted by timeline start). The playhead stays where it is. */
    fun setVideoClips(clips: List<PreviewClip>)
    /** Replace the music lane's clips (sorted by timeline start). */
    fun setAudioClips(clips: List<PreviewClip>)
    fun seekTo(ms: Long)
    fun play()
    fun pause()
    fun release()
}

private const val DRIFT_MS = 200L      // how far a player may stray from the clock before we re-seek it
private const val RESEEK_MS = 600L     // minimum time between corrective seeks (avoids a seek storm)

/**
 * Preview = ONE master clock + two "slave" players.
 *
 * The clock (system time) is the playhead. A video player and a music player each hold a playlist
 * of trimmed clips and are told, every frame, "you should be at item N, offset X": they seek only when
 * they have drifted. Consequences:
 *   - gaps play through (the slave pauses and holds its last frame / stays silent),
 *   - a project with only music plays too,
 *   - the music lane plays in sync with the video.
 *
 * Must be created and used on the main thread (ExoPlayer requirement).
 */
class ExoPreviewEngine(context: Context, scope: CoroutineScope) : PreviewEngine {

    private val video: ExoPlayer = ExoPlayer.Builder(context).build()
    private val music: ExoPlayer = ExoPlayer.Builder(context).build()
    override val videoPlayer: Player get() = video

    private val _position = MutableStateFlow(0L)
    override val positionMs: StateFlow<Long> = _position.asStateFlow()
    private val _playing = MutableStateFlow(false)
    override val isPlaying: StateFlow<Boolean> = _playing.asStateFlow()

    private val videoSlave = Slave(video)
    private val musicSlave = Slave(music)

    private var totalMs = 0L
    private var clockPosMs = 0L
    private var clockStartedAt = 0L

    // Kept so release() can stop the loop; otherwise it would outlive the players.
    private val pollJob: Job

    init {
        pollJob = scope.launch {
            _playing.collectLatest { playing ->
                if (playing) while (isActive && _playing.value) { tick(); delay(16) }
            }
        }
    }

    private fun restartClock() {
        clockPosMs = _position.value
        clockStartedAt = SystemClock.elapsedRealtime()
    }

    private fun tick() {
        val pos = clockPosMs + (SystemClock.elapsedRealtime() - clockStartedAt)
        if (pos >= totalMs) { stopAtEnd(); return }
        _position.value = pos
        videoSlave.sync(pos, playing = true)
        musicSlave.sync(pos, playing = true)
    }

    private fun stopAtEnd() {
        _playing.value = false
        _position.value = totalMs
        videoSlave.sync(totalMs, playing = false)
        musicSlave.sync(totalMs, playing = false)
    }

    private fun recomputeTotal() {
        totalMs = max(videoSlave.endMs(), musicSlave.endMs())
        if (_position.value > totalMs) _position.value = totalMs
        if (totalMs == 0L && _playing.value) _playing.value = false
        restartClock()
    }

    override fun setVideoClips(clips: List<PreviewClip>) {
        videoSlave.setClips(clips, _position.value, _playing.value)
        recomputeTotal()
    }

    override fun setAudioClips(clips: List<PreviewClip>) {
        musicSlave.setClips(clips, _position.value, _playing.value)
        recomputeTotal()
    }

    override fun seekTo(ms: Long) {
        val pos = ms.coerceIn(0L, totalMs)
        _position.value = pos
        restartClock()
        // force = true so a paused scrub still shows the frame under the playhead
        videoSlave.sync(pos, _playing.value, force = true)
        musicSlave.sync(pos, _playing.value, force = true)
    }

    override fun play() {
        if (totalMs <= 0L) return
        if (_position.value >= totalMs - 50) _position.value = 0L      // "Play" at the end restarts
        restartClock()
        _playing.value = true
        videoSlave.sync(_position.value, playing = true, force = true)
        musicSlave.sync(_position.value, playing = true, force = true)
    }

    override fun pause() {
        if (!_playing.value) return
        _playing.value = false
        videoSlave.sync(_position.value, playing = false)
        musicSlave.sync(_position.value, playing = false)
    }

    override fun release() {
        pollJob.cancel()
        video.release()
        music.release()
    }
}

/** One ExoPlayer holding a lane's clips as a playlist, kept in step with the master clock. */
internal class Slave(private val player: ExoPlayer) {
    private var clips: List<PreviewClip> = emptyList()
    private var lastSeekAt = 0L

    fun endMs(): Long = clips.maxOfOrNull { it.timelineEndMs } ?: 0L

    fun setClips(newClips: List<PreviewClip>, positionMs: Long, playing: Boolean) {
        if (newClips == clips) return
        clips = newClips
        if (newClips.isEmpty()) {
            player.clearMediaItems()
            return
        }
        player.setMediaItems(newClips.map { it.toMediaItem() }, /* resetPosition = */ true)
        player.prepare()
        sync(positionMs, playing, force = true)
    }

    fun sync(positionMs: Long, playing: Boolean, force: Boolean = false) {
        if (clips.isEmpty()) return
        val hit = PreviewMap.locate(clips, positionMs)
        if (hit == null) {                       // inside a gap (or past the end): hold still
            player.playWhenReady = false
            return
        }
        val (index, offset) = hit
        val onItem = player.currentMediaItemIndex == index
        val ready = player.playbackState == Player.STATE_READY
        // Only judge drift when the player is actually playing; a buffering player lags by definition.
        val drift = if (onItem && ready) abs(player.currentPosition - offset) else 0L
        val now = SystemClock.elapsedRealtime()
        val needsSeek = force || !onItem || (drift > DRIFT_MS && now - lastSeekAt > RESEEK_MS)
        if (needsSeek) {
            player.seekTo(index, offset)
            lastSeekAt = now
        }
        player.playWhenReady = playing
    }
}

private fun PreviewClip.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setUri(uri)
        .setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(sourceInMs)
                .setEndPositionMs(sourceOutMs)
                .build()
        )
        .build()
