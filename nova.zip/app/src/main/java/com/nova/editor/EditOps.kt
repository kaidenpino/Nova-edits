package com.nova.editor

import kotlin.math.abs
import kotlin.math.max

/* =====================================================================================
 *  EDIT OPERATIONS: pure functions over immutable Track/Clip values.
 *
 *  No Android, no coroutines, no state: every function takes values and returns new values,
 *  so they are trivially unit-testable (see EditOpsTest.kt) and undo is just "keep the old value".
 *  Nothing here touches media files; edits only change trim points and timeline positions.
 * ===================================================================================== */

enum class TrimEdge { START, END }

object EditOps {

    /** Clips shorter than this are refused: they are un-grabbable on a phone screen. */
    const val MIN_CLIP_MS = 100L

    /**
     * Splits the clip [clipId] at timeline position [atMs] into two adjacent clips that together
     * play exactly the same footage. Returns null if the split point is too close to an edge
     * (would create a sliver shorter than [MIN_CLIP_MS]) or the clip is not on this track.
     */
    fun split(track: Track, clipId: String, atMs: Long, leftId: String, rightId: String): Track? {
        val clip = track.clips.firstOrNull { it.id == clipId } ?: return null
        if (atMs - clip.timelineStartMs < MIN_CLIP_MS || clip.timelineEndMs - atMs < MIN_CLIP_MS) return null

        val sourceSplit = clip.sourceInMs + (atMs - clip.timelineStartMs)
        val left = clip.copy(id = leftId, sourceOutMs = sourceSplit)
        val right = clip.copy(id = rightId, timelineStartMs = atMs, sourceInMs = sourceSplit)

        return track.copy(
            clips = track.clips.flatMap { if (it.id == clipId) listOf(left, right) else listOf(it) }
        )
    }

    /**
     * Moves the clip's left edge to [newStartMs] while its right edge stays put.
     * Limits: cannot reveal footage before the start of the source, cannot pass t=0,
     * cannot shrink below [MIN_CLIP_MS].
     */
    fun trimStart(clip: Clip, newStartMs: Long): Clip {
        val lowest = max(0L, clip.timelineStartMs - clip.sourceInMs)
        val highest = clip.timelineEndMs - MIN_CLIP_MS
        if (highest < lowest) return clip
        val start = newStartMs.coerceIn(lowest, highest)
        val delta = start - clip.timelineStartMs
        return clip.copy(timelineStartMs = start, sourceInMs = clip.sourceInMs + delta)
    }

    /**
     * Moves the clip's right edge to [newEndMs] while its left edge stays put.
     * Limits: cannot reveal footage after the end of the source, cannot shrink below [MIN_CLIP_MS].
     */
    fun trimEnd(clip: Clip, newEndMs: Long): Clip {
        val available = clip.sourceDurationMs - clip.sourceInMs        // source footage still unused
        val lowest = clip.timelineStartMs + MIN_CLIP_MS
        val highest = clip.timelineStartMs + max(available, MIN_CLIP_MS)
        val end = newEndMs.coerceIn(lowest, highest)
        return clip.copy(sourceOutMs = clip.sourceInMs + (end - clip.timelineStartMs))
    }

    /** Applies whichever edge is being dragged to the timeline position the finger is at. */
    fun trim(clip: Clip, edge: TrimEdge, timelineMs: Long): Clip = when (edge) {
        TrimEdge.START -> trimStart(clip, timelineMs)
        TrimEdge.END -> trimEnd(clip, timelineMs)
    }

    /**
     * Removes a clip. With [ripple] every later clip on the track slides left to close the gap
     * (the usual behaviour on the main video track); without it the gap stays.
     */
    fun delete(track: Track, clipId: String, ripple: Boolean): Track {
        val target = track.clips.firstOrNull { it.id == clipId } ?: return track
        val rest = track.clips.filter { it.id != clipId }
        if (!ripple) return track.copy(clips = rest)
        val gap = target.durationMs
        return track.copy(clips = rest.map {
            if (it.timelineStartMs >= target.timelineEndMs) it.copy(timelineStartMs = it.timelineStartMs - gap) else it
        })
    }

    /**
     * Where can clip [clipId] actually sit so it overlaps nothing on this (single-lane) track?
     * Finds every gap big enough for the clip and returns the start inside a gap that is closest
     * to [desiredStartMs]. Dropping a clip onto another one therefore snaps it to the nearest
     * free slot instead of stacking two videos at the same time.
     */
    fun nearestFreeStart(track: Track, clipId: String, desiredStartMs: Long): Long {
        val clip = track.clips.first { it.id == clipId }
        val others = track.clips.filter { it.id != clipId }.sortedBy { it.timelineStartMs }
        val length = clip.durationMs
        val desired = desiredStartMs.coerceAtLeast(0L)

        var best = desired
        var bestDistance = Long.MAX_VALUE
        fun consider(gapStart: Long, gapEnd: Long) {
            if (gapEnd - gapStart < length) return
            val candidate = desired.coerceIn(gapStart, gapEnd - length)
            val distance = abs(candidate - desired)
            if (distance < bestDistance) { best = candidate; bestDistance = distance }
        }

        var gapStart = 0L
        for (other in others) {
            consider(gapStart, other.timelineStartMs)
            gapStart = max(gapStart, other.timelineEndMs)
        }
        consider(gapStart, Long.MAX_VALUE / 4)      // the open space after the last clip always fits
        return best
    }
}

/* =====================================================================================
 *  PREVIEW MAPPING: timeline time <-> (playlist item, offset inside that item)
 *
 *  The preview plays the video track as a playlist of trimmed clips. The player only knows
 *  "item 2, 1.4 s in"; the timeline needs "00:09.4". These two pure functions convert both ways.
 *  Clips must be sorted by timeline start and non-overlapping (EditOps.nearestFreeStart
 *  guarantees that on the video lane).
 *
 *  v1 limitation: playback skips GAPS between clips (a playlist has no "black" item), so the
 *  playhead jumps across a gap instead of playing through it. Seeking into a gap lands on the
 *  start of the next clip.
 * ===================================================================================== */

data class PreviewClip(
    val uri: String,
    val timelineStartMs: Long,
    val sourceInMs: Long,
    val sourceOutMs: Long,
) {
    val durationMs: Long get() = sourceOutMs - sourceInMs
    val timelineEndMs: Long get() = timelineStartMs + durationMs
}

object PreviewMap {

    /**
     * Playlist index and offset-into-clip for timeline position [ms]. A position inside a gap maps to
     * the start of the next clip; past the end maps to the end of the last clip; null when empty.
     */
    fun locate(clips: List<PreviewClip>, ms: Long): Pair<Int, Long>? {
        if (clips.isEmpty()) return null
        val found = clips.indexOfFirst { ms < it.timelineEndMs }
        val index = if (found == -1) clips.lastIndex else found
        val clip = clips[index]
        return index to (ms - clip.timelineStartMs).coerceIn(0L, clip.durationMs)
    }

    /** Timeline position of "[offsetMs] into playlist item [index]"; null if the index is out of range. */
    fun toTimeline(clips: List<PreviewClip>, index: Int, offsetMs: Long): Long? =
        clips.getOrNull(index)?.let { it.timelineStartMs + offsetMs.coerceIn(0L, it.durationMs) }
}
