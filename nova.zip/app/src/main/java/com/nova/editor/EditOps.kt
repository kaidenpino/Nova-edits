package com.nova.editor

import kotlin.math.abs
import kotlin.math.max

/* =====================================================================================
 *  EDIT OPERATIONS: pure functions over immutable Track/Clip values.
 *
 *  No Android, no coroutines, no state: every function takes values and returns new values,
 *  so they are trivially unit-testable (see NovaCoreTests.kt) and undo is just "keep the old value".
 *  Nothing here touches media files; edits only change trim points and timeline positions.
 * ===================================================================================== */

enum class TrimEdge { START, END }

object EditOps {

    /** Clips shorter than this are refused: they are un-grabbable on a phone screen. */
    const val MIN_CLIP_MS = 100L

    /**
     * Splits the clip [clipId] at timeline position [atMs] into two adjacent clips that together
     * play exactly the same footage. Returns null if the split point is too close to an edge
     * (would create a sliver shorter than [MIN_CLIP_MS]) or the clip is not on this track.
     */
    fun split(track: Track, clipId: String, atMs: Long, leftId: String, rightId: String): Track? {
        val clip = track.clips.firstOrNull { it.id == clipId } ?: return null
        if (atMs - clip.timelineStartMs < MIN_CLIP_MS || clip.timelineEndMs - atMs < MIN_CLIP_MS) return null

        val sourceSplit = clip.sourceInMs + (atMs - clip.timelineStartMs)
        val left = clip.copy(id = leftId, sourceOutMs = sourceSplit)
        val right = clip.copy(id = rightId, timelineStartMs = atMs, sourceInMs = sourceSplit)

        return track.copy(
            clips = track.clips.flatMap { if (it.id == clipId) listOf(left, right) else listOf(it) }
        )
    }

    /**
     * Moves the clip's left edge to [newStartMs] while its right edge stays put.
     * Limits: cannot reveal footage before the start of the source, cannot pass t=0,
     * cannot shrink below [MIN_CLIP_MS].
     */
    fun trimStart(clip: Clip, newStartMs: Long): Clip {
        val lowest = max(0L, clip.timelineStartMs - clip.sourceInMs)
        val highest = clip.timelineEndMs - MIN_CLIP_MS
        if (highest < lowest) return clip
        val start = newStartMs.coerceIn(lowest, highest)
        val delta = start - clip.timelineStartMs
        return clip.copy(timelineStartMs = start, sourceInMs = clip.sourceInMs + delta)
    }

    /**
     * Moves the clip's right edge to [newEndMs] while its left edge stays put.
     * Limits: cannot reveal footage after the end of the source, cannot shrink below [MIN_CLIP_MS].
     */
    fun trimEnd(clip: Clip, newEndMs: Long): Clip {
        val available = clip.sourceDurationMs - clip.sourceInMs        // source footage still unused
        val lowest = clip.timelineStartMs + MIN_CLIP_MS
        val highest = clip.timelineStartMs + max(available, MIN_CLIP_MS)
        val end = newEndMs.coerceIn(lowest, highest)
        return clip.copy(sourceOutMs = clip.sourceInMs + (end - clip.timelineStartMs))
    }

    /** Applies whichever edge is being dragged to the timeline position the finger is at. */
    fun trim(clip: Clip, edge: TrimEdge, timelineMs: Long): Clip = when (edge) {
        TrimEdge.START -> trimStart(clip, timelineMs)
        TrimEdge.END -> trimEnd(clip, timelineMs)
    }

    /** Removes a clip. With [ripple] every later clip slides left to close the gap. */
    fun delete(track: Track, clipId: String, ripple: Boolean): Track {
        val target = track.clips.firstOrNull { it.id == clipId } ?: return track
        val rest = track.clips.filter { it.id != clipId }
        if (!ripple) return track.copy(clips = rest)
        val gap = target.durationMs
        return track.copy(clips = rest.map {
            if (it.timelineStartMs >= target.timelineEndMs) it.copy(timelineStartMs = it.timelineStartMs - gap) else it
        })
    }

    /**
     * Where can clip [clipId] actually sit so it overlaps nothing on this (single-lane) track?
     * Finds every gap big enough for the clip and returns the start inside the gap closest to
     * [desiredStartMs]. Used for the music lane, where gaps are allowed but overlaps are not.
     */
    fun nearestFreeStart(track: Track, clipId: String, desiredStartMs: Long): Long {
        val clip = track.clips.first { it.id == clipId }
        val others = track.clips.filter { it.id != clipId }.sortedBy { it.timelineStartMs }
        val length = clip.durationMs
        val desired = desiredStartMs.coerceAtLeast(0L)

        var best = desired
        var bestDistance = Long.MAX_VALUE
        fun consider(gapStart: Long, gapEnd: Long) {
            if (gapEnd - gapStart < length) return
            val candidate = desired.coerceIn(gapStart, gapEnd - length)
            val distance = abs(candidate - desired)
            if (distance < bestDistance) { best = candidate; bestDistance = distance }
        }

        var gapStart = 0L
        for (other in others) {
            consider(gapStart, other.timelineStartMs)
            gapStart = max(gapStart, other.timelineEndMs)
        }
        consider(gapStart, Long.MAX_VALUE / 4)      // the open space after the last clip always fits
        return best
    }

    /* ------------------------- the magnetic main video track ------------------------- */

    /** Butts the clips together from t=0 in the given order (no gaps, no overlaps). */
    private fun butt(clips: List<Clip>): List<Clip> {
        var cursor = 0L
        return clips.map { c ->
            val placed = c.copy(timelineStartMs = cursor)
            cursor += c.durationMs
            placed
        }
    }

    /**
     * The main video track is "magnetic", like CapCut's: clips always sit back-to-back from the
     * start. Packing after every edit (trim, delete, split, import) keeps preview and export identical,
     * because neither ever has to guess what happens in a gap.
     */
    fun pack(track: Track): Track = track.copy(clips = butt(track.clips.sortedBy { it.timelineStartMs }))

    /**
     * Drag-to-reorder on the packed lane: clips are ordered by where their CENTRES sit, with the
     * dragged clip using its dropped position, then re-packed.
     */
    fun reorder(track: Track, clipId: String, desiredStartMs: Long): Track {
        val ordered = track.clips.sortedBy { c ->
            val start = if (c.id == clipId) desiredStartMs else c.timelineStartMs
            start + c.durationMs / 2
        }
        return track.copy(clips = butt(ordered))
    }
}

/** Magnetic snapping while dragging a clip on the music lane. */
object Snapper {
    /**
     * Snaps either edge of a clip to the nearest target within [thresholdMs].
     * Targets: playhead, video clip edges, other music clips' edges.
     */
    fun snap(startMs: Long, durationMs: Long, targets: List<Long>, thresholdMs: Long): Long {
        var best = startMs
        var bestDist = thresholdMs + 1
        for (t in targets) {
            val dStart = abs(t - startMs)
            if (dStart < bestDist) { bestDist = dStart; best = t }
            val dEnd = abs(t - (startMs + durationMs))
            if (dEnd < bestDist) { bestDist = dEnd; best = t - durationMs }
        }
        return best.coerceAtLeast(0L)
    }
}

/* =====================================================================================
 *  PREVIEW MAPPING: which clip of a lane is playing at a given timeline position
 * ===================================================================================== */

data class PreviewClip(
    val uri: String,
    val timelineStartMs: Long,
    val sourceInMs: Long,
    val sourceOutMs: Long,
) {
    val durationMs: Long get() = sourceOutMs - sourceInMs
    val timelineEndMs: Long get() = timelineStartMs + durationMs
}

object PreviewMap {
    /**
     * Playlist index and offset-into-clip for timeline position [ms], or null when [ms] falls in a
     * gap or outside every clip (the player then holds still).
     */
    fun locate(clips: List<PreviewClip>, ms: Long): Pair<Int, Long>? {
        val index = clips.indexOfFirst { ms >= it.timelineStartMs && ms < it.timelineEndMs }
        return if (index < 0) null else index to (ms - clips[index].timelineStartMs)
    }
}
