package com.nova.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.nova.music.PEAKS_PER_SEC
import com.nova.ui.NovaColors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch

// Shared geometry: the lane icons pinned on the left must line up with the lanes in the scrolling area.
private val RULER_H = 26.dp
private val VIDEO_H = 62.dp
private val AUDIO_H = 50.dp
private val LANE_GAP = 6.dp
private val TOP_PAD = 6.dp
private val ADD_TILE_W = 56.dp
private val TAIL_W = 140.dp           // room after the last clip for the "+" tile / "Add music" hint

/**
 * The timeline.
 *  - The playhead is fixed at the centre; the content scrolls beneath it (like CapCut).
 *  - Two-finger pinch zooms; the moment under the playhead stays put.
 *  - Exactly one side drives the scroll position at a time: the player (while playing) or the
 *    user's finger (while scrubbing), so the two can never feed back into each other.
 */
@Composable
fun Timeline(
    state: EditorUiState,
    positionMs: StateFlow<Long>,
    snap: (clipId: String, candidateStartMs: Long) -> Long,
    onSeek: (Long) -> Unit,
    onZoom: (Float) -> Unit,
    onMoveClip: (clipId: String, newStartMs: Long) -> Unit,
    onTrim: (clipId: String, edge: TrimEdge, timelineMs: Long) -> Unit,
    onSelect: (String?) -> Unit,
    onAddVideo: () -> Unit,
    onAddMusic: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current.density
    val pps = state.pixelsPerSecond

    // Latest values for long-lived effects/gesture lambdas.
    val curPps by rememberUpdatedState(pps)
    val curSeek by rememberUpdatedState(onSeek)
    val curZoom by rememberUpdatedState(onZoom)
    var lastPosMs by remember { mutableLongStateOf(0L) }
    var userDriving by remember { mutableStateOf(false) }

    fun msToPx(ms: Long) = (ms / 1000f * curPps * density).roundToInt()
    fun pxToMs(px: Int) = (px / (curPps * density) * 1000f).toLong()

    LaunchedEffect(scroll) {
        launch {
            scroll.interactionSource.interactions.collect { interaction ->
                when (interaction) {
                    is DragInteraction.Start -> userDriving = true
                    // A tap-without-move never starts a scroll, so release control right away.
                    is DragInteraction.Stop, is DragInteraction.Cancel ->
                        if (!scroll.isScrollInProgress) userDriving = false
                }
            }
        }
        // Once the drag AND its fling have fully settled, hand control back to the player.
        launch {
            snapshotFlow { scroll.isScrollInProgress }
                .collect { moving -> if (!moving) userDriving = false }
        }
    }

    // Player -> timeline: follow the playhead.
    LaunchedEffect(Unit) {
        positionMs.collectLatest { ms ->
            lastPosMs = ms
            if (!userDriving) scroll.scrollTo(msToPx(ms))
        }
    }
    // User scrub -> player.
    LaunchedEffect(scroll) {
        snapshotFlow { scroll.value }
            .filter { userDriving }
            .collect { px -> curSeek(pxToMs(px)) }
    }
    // Zoom -> keep the same moment under the playhead.
    LaunchedEffect(pps) { scroll.scrollTo(msToPx(lastPosMs)) }

    BoxWithConstraints(
        modifier
            .background(NovaColors.Surface)
            // Intercept multi-touch BEFORE horizontalScroll sees it (Initial pass).
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.count { it.pressed } >= 2) {
                            val zoom = event.calculateZoom()
                            if (zoom != 1f) {
                                curZoom(zoom)
                                event.changes.forEach { it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        val half = maxWidth / 2                                   // so t=0 and t=end can reach the centre
        val contentWidth = (state.durationMs / 1000f * pps).dp
        val laneWidth = contentWidth + TAIL_W

        Column(
            Modifier
                .horizontalScroll(scroll)
                .width(laneWidth + half * 2)
                .padding(horizontal = half)
                .padding(top = TOP_PAD)
        ) {
            TimeRuler(laneWidth, pps, state.beatMarkersMs)
            Spacer(Modifier.height(LANE_GAP))
            state.tracks.forEach { track ->
                TrackLane(
                    track = track,
                    pps = pps,
                    laneWidth = laneWidth,
                    selectedClipId = state.selectedClipId,
                    snap = snap,
                    onMove = onMoveClip,
                    onTrim = onTrim,
                    onSelect = onSelect,
                    onAddVideo = onAddVideo,
                    onAddMusic = onAddMusic,
                )
                Spacer(Modifier.height(LANE_GAP))
            }
        }

        // Lane icons pinned to the left edge (they do not scroll).
        Column(Modifier.align(Alignment.TopStart).padding(top = TOP_PAD + RULER_H + LANE_GAP)) {
            LaneBadge(VIDEO_H) { Icon(Icons.Rounded.VideoLibrary, null, tint = NovaColors.TextSecondary, modifier = Modifier.size(15.dp)) }
            Spacer(Modifier.height(LANE_GAP))
            LaneBadge(AUDIO_H) { Icon(Icons.Rounded.MusicNote, null, tint = NovaColors.TextSecondary, modifier = Modifier.size(15.dp)) }
        }

        // Fixed playhead: a line with a round handle on top.
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.White)
        )
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .size(10.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

@Composable
private fun LaneBadge(height: Dp, content: @Composable () -> Unit) {
    Box(
        Modifier
            .width(24.dp)
            .height(height)
            .background(NovaColors.Surface.copy(alpha = 0.88f), RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp)),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun TimeRuler(width: Dp, pps: Float, beatsMs: List<Long>) {
    val measurer = rememberTextMeasurer()
    val tickColor = NovaColors.TextSecondary
    val labelStyle = remember(tickColor) { TextStyle(fontSize = 9.sp, color = tickColor) }

    Canvas(Modifier.width(width).height(RULER_H)) {
        // Adaptive tick spacing so labels never overlap at any zoom level.
        val stepSec = when {
            pps >= 160f -> 1
            pps >= 60f -> 2
            pps >= 30f -> 5
            else -> 10
        }
        val pxPerSec = pps * density
        var t = 0
        while (t * pxPerSec <= size.width) {
            val x = t * pxPerSec
            drawLine(tickColor, Offset(x, size.height * 0.55f), Offset(x, size.height * 0.8f), 1f)
            // Measure unconstrained, THEN draw the measured layout. The convenience overload constrains the
            // text to the space left of `topLeft`; a tick on the canvas edge makes that width negative and
            // throws IllegalArgumentException on the first frame.
            val label = measurer.measure("${t}s", labelStyle)
            drawText(label, topLeft = Offset(x + 3f, 0f))
            t += stepSec
        }
        // Beat markers: also act as the rhythm guide for cutting.
        beatsMs.forEach { ms ->
            drawCircle(
                NovaColors.Beat,
                radius = 2.5f * density,
                center = Offset(ms / 1000f * pxPerSec, size.height - 3f * density),
            )
        }
    }
}

@Composable
private fun TrackLane(
    track: Track,
    pps: Float,
    laneWidth: Dp,
    selectedClipId: String?,
    snap: (String, Long) -> Long,
    onMove: (String, Long) -> Unit,
    onTrim: (String, TrimEdge, Long) -> Unit,
    onSelect: (String?) -> Unit,
    onAddVideo: () -> Unit,
    onAddMusic: () -> Unit,
) {
    val isVideo = track.type == TrackType.VIDEO
    val noRipple = remember { MutableInteractionSource() }
    val endMs = track.clips.maxOfOrNull { it.timelineEndMs } ?: 0L

    Box(
        Modifier
            .width(laneWidth)
            .height(if (isVideo) VIDEO_H else AUDIO_H)
            .clickable(interactionSource = noRipple, indication = null) { onSelect(null) }
    ) {
        track.clips.forEach { clip ->
            key(clip.id) {
                ClipBlock(
                    clip = clip,
                    type = track.type,
                    pps = pps,
                    selected = clip.id == selectedClipId,
                    snap = snap,
                    onMove = onMove,
                    onTrim = onTrim,
                    onSelect = onSelect,
                )
            }
        }

        if (isVideo) {
            // CapCut-style "+" right after the last clip.
            Box(
                Modifier
                    .offset(x = (endMs / 1000f * pps).dp + 8.dp)
                    .width(ADD_TILE_W)
                    .fillMaxHeight()
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NovaColors.SurfaceHigh)
                    .clickable(onClick = onAddVideo),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Add video", tint = NovaColors.Accent)
            }
        } else if (track.clips.isEmpty()) {
            Row(
                Modifier
                    .offset(x = 8.dp)
                    .height(AUDIO_H)
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NovaColors.SurfaceHigh)
                    .clickable(onClick = onAddMusic)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Rounded.MusicNote, null, tint = NovaColors.Accent, modifier = Modifier.size(16.dp))
                Text("Add music", color = NovaColors.TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

/**
 * Gestures on a clip:
 *  - tap ................... select
 *  - long-press + drag ..... move (video lane: reorder; music lane: free placement with snapping)
 *  - drag a teal handle .... trim that edge (live preview, committed on release); handles only
 *                            appear on the selected clip so they can't be grabbed by accident
 *
 * All in-flight gesture state is LOCAL. The ViewModel hears about a gesture exactly once, when it
 * finishes, so a drag never triggers a project-wide recomposition per pointer event.
 */
@Composable
private fun ClipBlock(
    clip: Clip,
    type: TrackType,
    pps: Float,
    selected: Boolean,
    snap: (String, Long) -> Long,
    onMove: (String, Long) -> Unit,
    onTrim: (String, TrimEdge, Long) -> Unit,
    onSelect: (String?) -> Unit,
) {
    val density = LocalDensity.current.density

    // Gesture lambdas live across recompositions, so they must read the LATEST values through these
    // holders; capturing `clip` directly would freeze its pre-move position.
    val curClip by rememberUpdatedState(clip)
    val curSnap by rememberUpdatedState(snap)
    val curMove by rememberUpdatedState(onMove)
    val curTrim by rememberUpdatedState(onTrim)
    val curSelect by rememberUpdatedState(onSelect)
    val curPps by rememberUpdatedState(pps)

    var moveDx by remember(clip.id) { mutableFloatStateOf(0f) }
    var moving by remember(clip.id) { mutableStateOf(false) }
    var headDx by remember(clip.id) { mutableFloatStateOf(0f) }
    var tailDx by remember(clip.id) { mutableFloatStateOf(0f) }

    fun dxToMs(dx: Float) = (dx / (curPps * density) * 1000f).toLong()

    // What to draw right now: the clip as it will look if the in-flight trim were released here.
    val live = when {
        headDx != 0f -> EditOps.trimStart(clip, clip.timelineStartMs + dxToMs(headDx))
        tailDx != 0f -> EditOps.trimEnd(clip, clip.timelineEndMs + dxToMs(tailDx))
        else -> clip
    }
    val shownStartMs =
        if (moving) snap(clip.id, clip.timelineStartMs + dxToMs(moveDx)) else live.timelineStartMs
    val widthDp = (live.durationMs / 1000f * pps).dp
    val shape = RoundedCornerShape(8.dp)
    val isVideo = type == TrackType.VIDEO

    Box(
        Modifier
            .zIndex(if (moving) 1f else 0f)
            .offset { IntOffset((shownStartMs / 1000f * pps * density).roundToInt(), 0) }
            .width(widthDp)
            .fillMaxHeight()
            .padding(vertical = 2.dp)
            .clip(shape)
            .background((if (isVideo) NovaColors.VideoClip else NovaColors.AudioClip).copy(alpha = if (moving) 0.8f else 1f))
            .clickable { onSelect(clip.id) }
            .pointerInput(clip.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { moving = true; curSelect(curClip.id) },
                    onDrag = { change, delta -> change.consume(); moveDx += delta.x },
                    onDragEnd = {
                        val c = curClip
                        curMove(c.id, curSnap(c.id, c.timelineStartMs + dxToMs(moveDx)))
                        moveDx = 0f; moving = false
                    },
                    onDragCancel = { moveDx = 0f; moving = false },
                )
            }
    ) {
        if (isVideo) {
            ThumbnailStrip(
                uri = live.sourceUri,
                sourceInMs = live.sourceInMs,
                pixelsPerSecond = pps,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            live.peaks?.let { peaks ->
                Waveform(
                    peaks = peaks,
                    fromMs = live.sourceInMs,
                    toMs = live.sourceOutMs,
                    color = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.fillMaxSize().padding(vertical = 6.dp),
                )
            }
        }

        if (widthDp > 72.dp) {
            Text(
                text = clip.label,
                color = Color.White,
                fontSize = 10.sp,
                maxLines = 1,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = if (selected) 22.dp else 6.dp, bottom = 3.dp)
                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
            )
        }

        // Selection ring on TOP of the thumbnails (a border modifier on the parent would be painted underneath).
        if (selected || moving) {
            Box(Modifier.fillMaxSize().border(2.dp, NovaColors.Accent, shape))
        }

        if (selected && !moving) {
            TrimHandle(
                modifier = Modifier.align(Alignment.CenterStart),
                onDrag = { headDx += it },
                onEnd = {
                    val c = curClip
                    val target = c.timelineStartMs + dxToMs(headDx)
                    headDx = 0f
                    curTrim(c.id, TrimEdge.START, target)
                },
                onCancel = { headDx = 0f },
            )
            TrimHandle(
                modifier = Modifier.align(Alignment.CenterEnd),
                onDrag = { tailDx += it },
                onEnd = {
                    val c = curClip
                    val target = c.timelineEndMs + dxToMs(tailDx)
                    tailDx = 0f
                    curTrim(c.id, TrimEdge.END, target)
                },
                onCancel = { tailDx = 0f },
            )
        }
    }
}

/** An 18dp-wide grab bar on a clip edge. Wide enough for a thumb; callbacks report raw dx pixels. */
@Composable
private fun TrimHandle(
    modifier: Modifier,
    onDrag: (Float) -> Unit,
    onEnd: () -> Unit,
    onCancel: () -> Unit,
) {
    val curDrag by rememberUpdatedState(onDrag)
    val curEnd by rememberUpdatedState(onEnd)
    val curCancel by rememberUpdatedState(onCancel)
    Box(
        modifier
            .width(18.dp)
            .fillMaxHeight()
            .background(NovaColors.Accent)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = { curEnd() },
                    onDragCancel = { curCancel() },
                ) { change, amount -> change.consume(); curDrag(amount) }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.width(3.dp).height(20.dp).background(NovaColors.OnAccent, RoundedCornerShape(2.dp)))
    }
}

/**
 * Draws the waveform slice [fromMs, toMs] in a single Canvas pass. Peaks are collapsed to at most one
 * column per pixel, so cost is bounded by the clip's on-screen width, not the song's length, and
 * zooming out stays cheap.
 */
@Composable
fun Waveform(
    peaks: FloatArray,
    fromMs: Long,
    toMs: Long,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier) {
        val from = (fromMs / 1000f * PEAKS_PER_SEC).toInt().coerceIn(0, peaks.size)
        val to = (toMs / 1000f * PEAKS_PER_SEC).toInt().coerceIn(from, peaks.size)
        val count = to - from
        if (count <= 0 || size.width < 1f) return@Canvas

        val columns = min(count, size.width.toInt().coerceAtLeast(1))
        val colWidth = size.width / columns
        val stroke = max(1f, colWidth * 0.7f)

        for (col in 0 until columns) {
            val s = from + col * count / columns
            val e = max(from + (col + 1) * count / columns, s + 1).coerceAtMost(to)
            var peak = 0f
            for (i in s until e) peak = max(peak, peaks[i])

            val h = max(2f, peak * size.height)          // min height keeps silence visible
            val x = col * colWidth + colWidth / 2
            drawLine(color, Offset(x, (size.height - h) / 2), Offset(x, (size.height + h) / 2), stroke)
        }
    }
}
