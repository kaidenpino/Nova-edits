package com.nova.editor

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.Canvas
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.MediaItem
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.nova.beat.BeatAnalyzer
import com.nova.music.BeatDetector
import com.nova.music.PEAKS_PER_SEC
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/* =====================================================================================
 *  MODEL: immutable, non-destructive (clips only *reference* sources)
 * ===================================================================================== */

enum class TrackType { VIDEO, AUDIO }

@Immutable
data class Clip(
    val id: String,
    val label: String,
    val sourceUri: String,
    val timelineStartMs: Long,   // where the clip sits on the timeline
    val sourceInMs: Long,        // trim in-point inside the source
    val sourceOutMs: Long,       // trim out-point inside the source
    // Full length of the source file; caps how far the out-point can be dragged. The default
    // ("unknown") is large but overflow-safe. Set the real value when importing media.
    val sourceDurationMs: Long = Long.MAX_VALUE / 4,
    val peaks: FloatArray? = null, // audio only; PEAKS_PER_SEC resolution. Compared by reference.
) {
    val durationMs get() = sourceOutMs - sourceInMs
    val timelineEndMs get() = timelineStartMs + durationMs
}

@Immutable
data class Track(val id: String, val type: TrackType, val clips: List<Clip>)

@Immutable
data class EditorUiState(
    val tracks: List<Track> = emptyList(),
    val pixelsPerSecond: Float = 80f,          // dp per second: the zoom level
    val beatMarkersMs: List<Long> = emptyList(),
    val selectedClipId: String? = null,
    val canUndo: Boolean = false,
    val message: String? = null,     // one-shot notice shown as a snackbar, then cleared
) {
    val durationMs: Long
        get() = tracks.flatMap { it.clips }.maxOfOrNull { it.timelineEndMs } ?: 0L
}

/* =====================================================================================
 *  SNAPPING: pure Kotlin, unit-testable
 * ===================================================================================== */

object Snapper {
    /**
     * Snaps either edge of a clip to the nearest target within [thresholdMs].
     * Targets: playhead, other clips' edges, beat markers.
     */
    fun snap(startMs: Long, durationMs: Long, targets: List<Long>, thresholdMs: Long): Long {
        var best = startMs
        var bestDist = thresholdMs + 1
        for (t in targets) {
            val dStart = abs(t - startMs)
            if (dStart < bestDist) { bestDist = dStart; best = t }
            val dEnd = abs(t - (startMs + durationMs))
            if (dEnd < bestDist) { bestDist = dEnd; best = t - durationMs }
        }
        return best.coerceAtLeast(0)
    }
}

/* =====================================================================================
 *  PREVIEW ENGINE: wraps the player; playhead is a SEPARATE high-frequency flow
 * ===================================================================================== */

interface PreviewEngine {
    val player: Player
    /** Playhead in TIMELINE time (not the position inside whichever clip happens to be playing). */
    val positionMs: StateFlow<Long>
    val isPlaying: StateFlow<Boolean>
    /** Replaces the playlist with the video track's clips (sorted by timeline start); keeps the playhead. */
    fun setClips(clips: List<PreviewClip>)
    fun seekTo(ms: Long)
    fun play()
    fun pause()
    fun release()
}

/**
 * v1 preview: the video track as an ExoPlayer playlist of trimmed clips (see PreviewMap for the
 * timeline <-> playlist conversion and the gap limitation). For true multi-track preview (video +
 * music + overlays) move to Media3 CompositionPlayer so the preview renders the SAME Composition you
 * export. Must be created and used on the main thread (ExoPlayer requirement).
 */
class ExoPreviewEngine(context: Context, scope: CoroutineScope) : PreviewEngine {
    override val player: ExoPlayer = ExoPlayer.Builder(context).build()

    private var clips: List<PreviewClip> = emptyList()

    private val _position = MutableStateFlow(0L)
    override val positionMs: StateFlow<Long> = _position.asStateFlow()
    private val _playing = MutableStateFlow(false)
    override val isPlaying: StateFlow<Boolean> = _playing.asStateFlow()

    // Kept so release() can stop the polling loop; otherwise it would outlive the player.
    private val pollJob: Job

    private fun timelinePosition(): Long =
        PreviewMap.toTimeline(clips, player.currentMediaItemIndex, player.currentPosition) ?: _position.value

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playing.value = isPlaying
                _position.value = timelinePosition()      // exact readout the moment playback pauses/stops
            }
        })
        // Poll ~60 Hz only while playing.
        pollJob = scope.launch {
            _playing.collectLatest { playing ->
                if (playing) while (isActive) { _position.value = timelinePosition(); delay(16) }
            }
        }
    }

    override fun setClips(clips: List<PreviewClip>) {
        if (clips == this.clips) return
        val resumeAt = _position.value
        val wasPlaying = player.playWhenReady
        this.clips = clips

        if (clips.isEmpty()) {
            player.clearMediaItems()
            _position.value = 0L
            return
        }
        player.setMediaItems(clips.map { it.toMediaItem() }, /* resetPosition = */ true)
        player.prepare()
        seekTo(resumeAt)                      // an edit must not move the playhead
        player.playWhenReady = wasPlaying
    }

    override fun seekTo(ms: Long) {
        val target = PreviewMap.locate(clips, ms)
        if (target == null) { _position.value = ms.coerceAtLeast(0L); return }
        val (index, offset) = target
        player.seekTo(index, offset)
        _position.value = PreviewMap.toTimeline(clips, index, offset) ?: ms
    }

    override fun play() {
        if (player.playbackState == Player.STATE_ENDED) seekTo(0L)   // "Play" at the end restarts
        player.play()
    }
    override fun pause() = player.pause()
    override fun release() { pollJob.cancel(); player.release() }

    private fun PreviewClip.toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(sourceInMs)
                    .setEndPositionMs(sourceOutMs)
                    .build()
            )
            .build()
}

/* =====================================================================================
 *  VIEWMODEL: reduces intents into immutable state; undo via snapshots
 * ===================================================================================== */

@HiltViewModel
class EditorViewModel @Inject constructor(
    val preview: PreviewEngine,
) : ViewModel() {

    private val _state = MutableStateFlow(demoState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    private val undoStack = ArrayDeque<EditorUiState>()

    init {
        // Beat markers from the audio clip, mapped into timeline time.
        val audio = _state.value.tracks.first { it.type == TrackType.AUDIO }.clips.first()
        val beats = audio.peaks?.let { BeatAnalyzer.analyze(it)?.beatsMs ?: BeatDetector.detect(it) }.orEmpty()
            .map { audio.timelineStartMs + it - audio.sourceInMs }
            .filter { it in audio.timelineStartMs..audio.timelineEndMs }
        _state.update { it.copy(beatMarkersMs = beats) }

        // Keep the preview playlist in sync with the video track after EVERY edit
        // (import, move, trim, split, delete, undo...). Position is preserved by the engine.
        viewModelScope.launch {
            state
                .map { s ->
                    s.tracks.filter { it.type == TrackType.VIDEO }
                        .flatMap { it.clips }
                        .sortedBy { it.timelineStartMs }
                        .map { PreviewClip(it.sourceUri, it.timelineStartMs, it.sourceInMs, it.sourceOutMs) }
                }
                .distinctUntilChanged()
                .collect { preview.setClips(it) }
        }
    }

    private data class VideoMeta(val label: String, val durationMs: Long)

    /** Blocking (disk/IO): call from Dispatchers.IO. Returns null if the file can't be read as video. */
    private fun readVideoMeta(context: Context, uri: Uri): VideoMeta? {
        val duration = MediaMetadataRetriever().let { r ->
            try {
                r.setDataSource(context, uri)
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            } catch (e: Exception) {
                null
            } finally {
                r.release()
            }
        } ?: return null
        if (duration <= 0L) return null

        val name = runCatching {
            context.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull()
        return VideoMeta(label = name ?: "Video", durationMs = duration)
    }

    /** Called with the Photo Picker's result: reads the length off the main thread, then appends the clip. */
    fun onVideoPicked(context: Context, uri: Uri) {
        viewModelScope.launch {
            val meta = withContext(Dispatchers.IO) { readVideoMeta(context, uri) }
            if (meta == null) {
                _state.update { it.copy(message = "Couldn't read that video.") }
                return@launch
            }
            pushUndo()
            _state.update { s ->
                val lane = s.tracks.first { it.type == TrackType.VIDEO }
                val start = lane.clips.maxOfOrNull { it.timelineEndMs } ?: 0L   // append after the last clip
                val clip = Clip(
                    id = java.util.UUID.randomUUID().toString(),
                    label = meta.label,
                    sourceUri = uri.toString(),
                    timelineStartMs = start,
                    sourceInMs = 0L,
                    sourceOutMs = meta.durationMs,
                    sourceDurationMs = meta.durationMs,
                )
                s.copy(
                    tracks = s.tracks.map { if (it.id == lane.id) it.copy(clips = it.clips + clip) else it },
                    selectedClipId = clip.id,
                    canUndo = true,
                )
            }
        }
    }

    fun onMessageShown() = _state.update { it.copy(message = null) }

    fun onZoom(factor: Float) = _state.update {
        it.copy(pixelsPerSecond = (it.pixelsPerSecond * factor).coerceIn(10f, 800f))
    }

    fun onSeek(ms: Long) = preview.seekTo(ms.coerceAtLeast(0))

    fun onTogglePlay() = if (preview.isPlaying.value) preview.pause() else preview.play()

    fun onSelect(clipId: String?) = _state.update { it.copy(selectedClipId = clipId) }

    /** Called continuously during a drag so the UI can show the magnetic position. */
    fun snapPreview(clipId: String, candidateStartMs: Long): Long {
        val s = _state.value
        val all = s.tracks.flatMap { it.clips }
        val clip = all.first { it.id == clipId }
        val targets = buildList {
            add(preview.positionMs.value)
            addAll(s.beatMarkersMs)
            all.filter { it.id != clipId }.forEach { add(it.timelineStartMs); add(it.timelineEndMs) }
        }
        // Zoom-aware: ~8dp on screen regardless of zoom level.
        val thresholdMs = (SNAP_DP / s.pixelsPerSecond * 1000f).toLong()
        return Snapper.snap(candidateStartMs.coerceAtLeast(0), clip.durationMs, targets, thresholdMs)
    }

    /**
     * Applies [transform] to the track that owns [clipId]. If it returns null the edit is refused
     * and nothing changes (and no undo entry is created).
     */
    private fun editTrackOf(clipId: String, transform: (Track) -> Track?) {
        val track = _state.value.tracks.firstOrNull { t -> t.clips.any { it.id == clipId } } ?: return
        val updated = transform(track) ?: return
        pushUndo()
        _state.update { s ->
            s.copy(tracks = s.tracks.map { if (it.id == track.id) updated else it }, canUndo = true)
        }
    }

    /** Video lanes hold one clip at a time, so a dropped clip snaps to the nearest free slot. */
    fun onMoveClip(clipId: String, newStartMs: Long) = editTrackOf(clipId) { track ->
        val start = if (track.type == TrackType.VIDEO)
            EditOps.nearestFreeStart(track, clipId, newStartMs)
        else newStartMs.coerceAtLeast(0)
        track.copy(clips = track.clips.map { if (it.id == clipId) it.copy(timelineStartMs = start) else it })
    }

    /** Splits the selected clip (or the first clip under the playhead) at the playhead. */
    fun onSplitAtPlayhead() {
        val at = preview.positionMs.value
        val s = _state.value
        val underPlayhead = s.tracks.flatMap { it.clips }.filter { at in it.timelineStartMs..it.timelineEndMs }
        val target = underPlayhead.firstOrNull { it.id == s.selectedClipId } ?: underPlayhead.firstOrNull() ?: return
        val rightId = java.util.UUID.randomUUID().toString()
        editTrackOf(target.id) { EditOps.split(it, target.id, at, target.id, rightId) }
        // The left half keeps the original id, so the selection stays valid.
    }

    /** Ripple-deletes on the video track (closes the gap); leaves a gap on audio tracks. */
    fun onDeleteSelected() {
        val id = _state.value.selectedClipId ?: return
        editTrackOf(id) { EditOps.delete(it, id, ripple = it.type == TrackType.VIDEO) }
        _state.update { it.copy(selectedClipId = null) }
    }

    /** Committed once when a trim-handle drag ends (live feedback is drawn locally). */
    fun onTrim(clipId: String, edge: TrimEdge, timelineMs: Long) = editTrackOf(clipId) { track ->
        track.copy(clips = track.clips.map { if (it.id == clipId) EditOps.trim(it, edge, timelineMs) else it })
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        _state.value = prev.copy(canUndo = undoStack.isNotEmpty(), message = null)
    }

    private fun pushUndo() {
        undoStack.addLast(_state.value)
        if (undoStack.size > 100) undoStack.removeFirst()
    }

    override fun onCleared() = preview.release()

    private companion object {
        const val SNAP_DP = 8f

        /** Demo project: one video clip + one audio clip with a synthetic waveform. */
        fun demoState(): EditorUiState {
            val fakePeaks = FloatArray(30 * PEAKS_PER_SEC) { i ->
                val beat = if (i % 25 < 3) 1f else 0.35f        // a "kick" every 0.5 s
                (beat * (0.6f + 0.4f * abs(sin(i * 0.05f)))).coerceIn(0f, 1f)
            }
            return EditorUiState(
                tracks = listOf(
                    Track("v1", TrackType.VIDEO, emptyList()),
                    Track("a1", TrackType.AUDIO, listOf(
                        Clip("m1", "Demo song (silent)", "file://demo/song", 0, 0, 20_000, peaks = fakePeaks),
                    )),
                )
            )
        }
    }
}

/* =====================================================================================
 *  SCREEN
 * ===================================================================================== */

@Composable
fun EditorScreen(vm: EditorViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }

    // Android's built-in Photo Picker: no storage permission required.
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onVideoPicked(context.applicationContext, uri)
    }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.onMessageShown() }
    }

    val hasVideo = state.tracks.any { it.type == TrackType.VIDEO && it.clips.isNotEmpty() }

    Scaffold(
        containerColor = Color(0xFF0E0E10),
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {

            Box(
                Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                PreviewSurface(player = vm.preview.player, modifier = Modifier.fillMaxSize())
                if (!hasVideo) {
                    Text("Tap Import to add a video", color = Color.White.copy(alpha = 0.7f))
                }
            }

            TransportBar(
                preview = vm.preview,
                canUndo = state.canUndo,
                hasSelection = state.selectedClipId != null,
                onTogglePlay = vm::onTogglePlay,
                onUndo = vm::undo,
                onSplit = vm::onSplitAtPlayhead,
                onDelete = vm::onDeleteSelected,
                onImport = {
                    pickVideo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                },
            )

            Timeline(
                state = state,
                positionMs = vm.preview.positionMs,
                snap = vm::snapPreview,
                onSeek = vm::onSeek,
                onZoom = vm::onZoom,
                onMoveClip = vm::onMoveClip,
                onTrim = vm::onTrim,
                onSelect = vm::onSelect,
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
        }
    }
}

/** Hardware-decoded video surface. Controls are ours, so `useController = false`. */
@Composable
fun PreviewSurface(player: Player, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = player
            }
        },
        update = { it.player = player },
    )
}

@Composable
private fun TransportBar(
    preview: PreviewEngine,
    canUndo: Boolean,
    hasSelection: Boolean,
    onTogglePlay: () -> Unit,
    onUndo: () -> Unit,
    onSplit: () -> Unit,
    onDelete: () -> Unit,
    onImport: () -> Unit,
) {
    val playing by preview.isPlaying.collectAsStateWithLifecycle()
    // Two rows so five controls fit a narrow phone: time + play on top, edit actions below.
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TimeReadout(preview.positionMs)
            TextButton(onClick = onTogglePlay) { Text(if (playing) "Pause" else "Play") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onImport) { Text("Import") }
            TextButton(onClick = onSplit) { Text("Split") }
            TextButton(onClick = onDelete, enabled = hasSelection) { Text("Delete") }
            TextButton(onClick = onUndo, enabled = canUndo) { Text("Undo") }
        }
    }
}

/** The ONLY composable that recomposes at playback rate. */
@Composable
private fun TimeReadout(positionMs: StateFlow<Long>) {
    val ms by positionMs.collectAsStateWithLifecycle()
    Text(
        text = "%d:%02d.%d".format(ms / 60_000, ms / 1000 % 60, ms % 1000 / 100),
        color = Color.White,
        style = MaterialTheme.typography.labelLarge,
    )
}

/* =====================================================================================
 *  TIMELINE
 *  - Playhead is fixed at the center; the content scrolls beneath it (like CapCut).
 *  - Scroll offset <-> time mapping keeps preview and timeline in sync.
 *  - Two-finger pinch zooms; the playhead time stays anchored while zooming.
 * ===================================================================================== */

@Composable
fun Timeline(
    state: EditorUiState,
    positionMs: StateFlow<Long>,
    snap: (clipId: String, candidateStartMs: Long) -> Long,
    onSeek: (Long) -> Unit,
    onZoom: (Float) -> Unit,
    onMoveClip: (clipId: String, newStartMs: Long) -> Unit,
    onTrim: (clipId: String, edge: TrimEdge, timelineMs: Long) -> Unit,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current.density
    val pps = state.pixelsPerSecond

    // Latest values for long-lived effects/gesture lambdas.
    val curPps by rememberUpdatedState(pps)
    val curSeek by rememberUpdatedState(onSeek)
    val curZoom by rememberUpdatedState(onZoom)
    var lastPosMs by remember { mutableLongStateOf(0L) }

    fun msToPx(ms: Long) = (ms / 1000f * curPps * density).roundToInt()
    fun pxToMs(px: Int) = (px / (curPps * density) * 1000f).toLong()

    // Exactly one side drives the scroll position at a time, which rules out a feedback loop:
    //   userDriving == false -> the PLAYER moves the timeline (we scrollTo the playhead)
    //   userDriving == true  -> the USER moves the timeline (we seek the player)
    // Note: `scroll.isScrollInProgress` is ALSO true during our own programmatic scrollTo, so it
    // cannot tell the two apart; the drag interaction can.
    var userDriving by remember { mutableStateOf(false) }
    LaunchedEffect(scroll) {
        launch {
            scroll.interactionSource.interactions.collect { interaction ->
                when (interaction) {
                    is DragInteraction.Start -> userDriving = true
                    // A tap-without-move never starts a scroll, so release control right away.
                    is DragInteraction.Stop, is DragInteraction.Cancel ->
                        if (!scroll.isScrollInProgress) userDriving = false
                }
            }
        }
        // Once the drag AND its fling have fully settled, hand control back to the player.
        launch {
            androidx.compose.runtime.snapshotFlow { scroll.isScrollInProgress }
                .collect { moving -> if (!moving) userDriving = false }
        }
    }

    // Player -> timeline: follow the playhead without recomposing anything.
    LaunchedEffect(Unit) {
        positionMs.collectLatest { ms ->
            lastPosMs = ms
            if (!userDriving) scroll.scrollTo(msToPx(ms))
        }
    }
    // User scrub -> player.
    LaunchedEffect(scroll) {
        androidx.compose.runtime.snapshotFlow { scroll.value }
            .filter { userDriving }
            .collect { px -> curSeek(pxToMs(px)) }
    }
    // Zoom -> keep the same moment under the playhead.
    LaunchedEffect(pps) { scroll.scrollTo(msToPx(lastPosMs)) }

    BoxWithConstraints(
        modifier
            .background(Color(0xFF17171A))
            // Intercept multi-touch BEFORE horizontalScroll sees it (Initial pass).
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.count { it.pressed } >= 2) {
                            val zoom = event.calculateZoom()
                            if (zoom != 1f) {
                                curZoom(zoom)
                                event.changes.forEach { it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        val half = maxWidth / 2                                  // so t=0 and t=end can reach the center
        val contentWidth = (state.durationMs / 1000f * pps).dp

        Column(
            Modifier
                .horizontalScroll(scroll)
                .width(contentWidth + half * 2)
                .padding(horizontal = half)
                .padding(vertical = 8.dp)
        ) {
            TimeRuler(contentWidth, pps, state.beatMarkersMs)

            state.tracks.forEach { track ->
                TrackLane(
                    track = track,
                    pps = pps,
                    contentWidth = contentWidth,
                    selectedClipId = state.selectedClipId,
                    snap = snap,
                    onMove = onMoveClip,
                    onTrim = onTrim,
                    onSelect = onSelect,
                )
            }
        }

        // Fixed playhead
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.White)
        )
    }
}

@Composable
private fun TimeRuler(contentWidth: androidx.compose.ui.unit.Dp, pps: Float, beatsMs: List<Long>) {
    val measurer = rememberTextMeasurer()
    val tickColor = Color(0xFF8A8A93)
    val beatColor = Color(0xFFFFC857)

    Canvas(Modifier.width(contentWidth).height(22.dp)) {
        // Adaptive tick spacing so labels never overlap at any zoom level.
        val stepSec = when {
            pps >= 160f -> 1
            pps >= 60f -> 2
            pps >= 30f -> 5
            else -> 10
        }
        val pxPerSec = pps * density
        var t = 0
        while (t * pxPerSec <= size.width) {
            val x = t * pxPerSec
            drawLine(tickColor, Offset(x, size.height * 0.5f), Offset(x, size.height * 0.8f), 1f)
            drawText(measurer, "${t}s", Offset(x + 3f, 0f), TextStyle(fontSize = 9.sp, color = tickColor))
            t += stepSec
        }
        // Beat markers: also act as snap targets.
        beatsMs.forEach { ms ->
            drawCircle(beatColor, radius = 2.5f * density, center = Offset(ms / 1000f * pxPerSec, size.height - 3f * density))
        }
    }
}

@Composable
private fun TrackLane(
    track: Track,
    pps: Float,
    contentWidth: androidx.compose.ui.unit.Dp,
    selectedClipId: String?,
    snap: (String, Long) -> Long,
    onMove: (String, Long) -> Unit,
    onTrim: (String, TrimEdge, Long) -> Unit,
    onSelect: (String?) -> Unit,
) {
    val height = if (track.type == TrackType.VIDEO) 64.dp else 48.dp
    Box(
        Modifier
            .width(contentWidth)
            .height(height)
            .padding(vertical = 2.dp)
            .clickable { onSelect(null) }
    ) {
        track.clips.forEach { clip ->
            androidx.compose.runtime.key(clip.id) {
                ClipBlock(
                    clip = clip,
                    type = track.type,
                    pps = pps,
                    selected = clip.id == selectedClipId,
                    snap = snap,
                    onMove = onMove,
                    onTrim = onTrim,
                    onSelect = onSelect,
                )
            }
        }
    }
}

/**
 * Gestures on a clip:
 *  - tap ................... select
 *  - long-press + drag ..... move (magnetic snap shown live, committed on release)
 *  - drag a white handle ... trim that edge (live preview, committed on release); handles only
 *                            appear on the selected clip so they can't be grabbed by accident
 *
 * All in-flight gesture state is LOCAL. The ViewModel hears about a gesture exactly once, when it
 * finishes, so a drag never triggers a project-wide recomposition per pointer event.
 */
@Composable
private fun ClipBlock(
    clip: Clip,
    type: TrackType,
    pps: Float,
    selected: Boolean,
    snap: (String, Long) -> Long,
    onMove: (String, Long) -> Unit,
    onTrim: (String, TrimEdge, Long) -> Unit,
    onSelect: (String?) -> Unit,
) {
    val density = LocalDensity.current.density

    // Gesture lambdas live across recompositions, so they must read the LATEST values through
    // these holders; capturing `clip` directly would freeze its pre-move position.
    val curClip by rememberUpdatedState(clip)
    val curSnap by rememberUpdatedState(snap)
    val curMove by rememberUpdatedState(onMove)
    val curTrim by rememberUpdatedState(onTrim)
    val curSelect by rememberUpdatedState(onSelect)
    val curPps by rememberUpdatedState(pps)

    var moveDx by remember(clip.id) { mutableFloatStateOf(0f) }
    var moving by remember(clip.id) { mutableStateOf(false) }
    var headDx by remember(clip.id) { mutableFloatStateOf(0f) }
    var tailDx by remember(clip.id) { mutableFloatStateOf(0f) }

    fun dxToMs(dx: Float) = (dx / (curPps * density) * 1000f).toLong()

    // What to draw right now: the clip as it will look if the in-flight trim were released here.
    val live = when {
        headDx != 0f -> EditOps.trimStart(clip, clip.timelineStartMs + dxToMs(headDx))
        tailDx != 0f -> EditOps.trimEnd(clip, clip.timelineEndMs + dxToMs(tailDx))
        else -> clip
    }
    val shownStartMs =
        if (moving) snap(clip.id, clip.timelineStartMs + dxToMs(moveDx)) else live.timelineStartMs
    val baseColor = if (type == TrackType.VIDEO) Color(0xFF3B5BDB) else Color(0xFF2B8A3E)
    val shape = RoundedCornerShape(6.dp)

    Box(
        Modifier
            .offset { IntOffset((shownStartMs / 1000f * pps * density).roundToInt(), 0) }
            .width((live.durationMs / 1000f * pps).dp)
            .fillMaxHeight()
            .clip(shape)
            .background(baseColor.copy(alpha = if (moving) 0.75f else 1f))
            .border(width = if (selected || moving) 2.dp else 0.dp, color = Color.White, shape = shape)
            .clickable { onSelect(clip.id) }
            .pointerInput(clip.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { moving = true; curSelect(curClip.id) },
                    onDrag = { change, delta -> change.consume(); moveDx += delta.x },
                    onDragEnd = {
                        val c = curClip
                        curMove(c.id, curSnap(c.id, c.timelineStartMs + dxToMs(moveDx)))
                        moveDx = 0f; moving = false
                    },
                    onDragCancel = { moveDx = 0f; moving = false },
                )
            }
    ) {
        live.peaks?.let { peaks ->
            Waveform(
                peaks = peaks,
                fromMs = live.sourceInMs,
                toMs = live.sourceOutMs,
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.fillMaxSize().padding(vertical = 4.dp),
            )
        }
        // Video thumbnails: render a strip via Coil's VideoFrameDecoder + a disk cache.
        Text(
            text = clip.label,
            color = Color.White,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(start = if (selected) 22.dp else 6.dp, top = 6.dp),
        )

        if (selected && !moving) {
            TrimHandle(
                modifier = Modifier.align(Alignment.CenterStart),
                onDrag = { headDx += it },
                onEnd = {
                    val c = curClip
                    val target = c.timelineStartMs + dxToMs(headDx)
                    headDx = 0f
                    curTrim(c.id, TrimEdge.START, target)
                },
                onCancel = { headDx = 0f },
            )
            TrimHandle(
                modifier = Modifier.align(Alignment.CenterEnd),
                onDrag = { tailDx += it },
                onEnd = {
                    val c = curClip
                    val target = c.timelineEndMs + dxToMs(tailDx)
                    tailDx = 0f
                    curTrim(c.id, TrimEdge.END, target)
                },
                onCancel = { tailDx = 0f },
            )
        }
    }
}

/** An 18dp-wide grab bar on a clip edge. Wide enough for a thumb; drag callbacks report raw dx pixels. */
@Composable
private fun TrimHandle(
    modifier: Modifier,
    onDrag: (Float) -> Unit,
    onEnd: () -> Unit,
    onCancel: () -> Unit,
) {
    val curDrag by rememberUpdatedState(onDrag)
    val curEnd by rememberUpdatedState(onEnd)
    val curCancel by rememberUpdatedState(onCancel)
    Box(
        modifier
            .width(18.dp)
            .fillMaxHeight()
            .background(Color.White.copy(alpha = 0.92f))
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = { curEnd() },
                    onDragCancel = { curCancel() },
                ) { change, amount -> change.consume(); curDrag(amount) }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.width(3.dp).height(20.dp).background(Color(0xFF17171A), RoundedCornerShape(2.dp)))
    }
}

/**
 * Draws the waveform slice [fromMs, toMs] in a single Canvas pass.
 * Peaks are collapsed to at most one column per pixel, so cost is bounded by the
 * clip's on-screen width, not the song's length, and zooming out stays cheap.
 */
@Composable
fun Waveform(
    peaks: FloatArray,
    fromMs: Long,
    toMs: Long,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier) {
        val from = (fromMs / 1000f * PEAKS_PER_SEC).toInt().coerceIn(0, peaks.size)
        val to = (toMs / 1000f * PEAKS_PER_SEC).toInt().coerceIn(from, peaks.size)
        val count = to - from
        if (count <= 0 || size.width < 1f) return@Canvas

        val columns = min(count, size.width.toInt().coerceAtLeast(1))
        val colWidth = size.width / columns
        val stroke = max(1f, colWidth * 0.7f)

        for (col in 0 until columns) {
            val s = from + col * count / columns
            val e = max(from + (col + 1) * count / columns, s + 1).coerceAtMost(to)
            var peak = 0f
            for (i in s until e) peak = max(peak, peaks[i])

            val h = max(2f, peak * size.height)          // min height keeps silence visible
            val x = col * colWidth + colWidth / 2
            drawLine(color, Offset(x, (size.height - h) / 2), Offset(x, (size.height + h) / 2), stroke)
        }
    }
}
