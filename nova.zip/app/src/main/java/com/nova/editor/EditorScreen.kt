package com.nova.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.nova.beat.CutRhythm
import com.nova.music.MusicSheet
import com.nova.ui.NovaColors
import kotlinx.coroutines.flow.StateFlow

@Composable
fun EditorScreen(vm: EditorViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var showMusic by rememberSaveable { mutableStateOf(false) }
    var showBeatSync by rememberSaveable { mutableStateOf(false) }

    // Android's built-in Photo Picker: no storage permission required.
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onVideoPicked(context.applicationContext, uri)
    }
    val addVideo = { pickVideo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.onMessageShown() }
    }

    val hasVideo = state.videoClips.isNotEmpty()
    val hasSongWithBeats = state.audioClips.any { it.beatsMs.isNotEmpty() }
    val exporting = state.export is ExportState.Running

    Scaffold(
        containerColor = NovaColors.Background,
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TopBar(canExport = hasVideo && !exporting, onExport = vm::onExport)

            PreviewPanel(
                player = vm.preview.videoPlayer,
                isPlaying = vm.preview.isPlaying,
                hasVideo = hasVideo,
                canPlay = state.durationMs > 0,
                onTogglePlay = vm::onTogglePlay,
            )

            PlaybackBar(
                positionMs = vm.preview.positionMs,
                isPlaying = vm.preview.isPlaying,
                durationMs = state.durationMs,
                onTogglePlay = vm::onTogglePlay,
            )

            Timeline(
                state = state,
                positionMs = vm.preview.positionMs,
                snap = vm::snapPreview,
                onSeek = vm::onSeek,
                onZoom = vm::onZoom,
                onMoveClip = vm::onMoveClip,
                onTrim = vm::onTrim,
                onSelect = vm::onSelect,
                onAddVideo = { addVideo() },
                onAddMusic = { showMusic = true },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )

            BottomToolbar(
                hasSelection = state.selectedClipId != null,
                canSplit = state.durationMs > 0,
                canBeatSync = hasVideo && hasSongWithBeats,
                canUndo = state.canUndo,
                onMedia = { addVideo() },
                onMusic = { showMusic = true },
                onBeatSync = { showBeatSync = true },
                onSplit = vm::onSplitAtPlayhead,
                onDelete = vm::onDeleteSelected,
                onUndo = vm::undo,
            )
        }
    }

    if (showMusic) {
        MusicSheet(
            onDismiss = { showMusic = false },
            onUse = { audio -> vm.onMusicReady(audio); showMusic = false },
        )
    }
    if (showBeatSync) {
        BeatSyncDialog(
            onPick = { rhythm -> showBeatSync = false; vm.onBeatSync(rhythm) },
            onDismiss = { showBeatSync = false },
        )
    }
    ExportDialogs(state.export, onCancel = vm::cancelExport, onDismiss = vm::dismissExport)
}

/* ------------------------------ top bar / preview / transport ------------------------------ */

@Composable
private fun TopBar(canExport: Boolean, onExport: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Nova", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Button(
            onClick = onExport,
            enabled = canExport,
            shape = RoundedCornerShape(50),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
        ) { Text("Export", fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun PreviewPanel(
    player: Player,
    isPlaying: StateFlow<Boolean>,
    hasVideo: Boolean,
    canPlay: Boolean,
    onTogglePlay: () -> Unit,
) {
    val playing by isPlaying.collectAsStateWithLifecycle()
    Box(
        Modifier
            .padding(horizontal = 12.dp)
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black)
            .clickable(enabled = canPlay) { onTogglePlay() },
        contentAlignment = Alignment.Center,
    ) {
        PreviewSurface(player = player, modifier = Modifier.fillMaxSize())
        if (!hasVideo) {
            Text(
                if (canPlay) "Music only. Tap + to add a video" else "Tap + to add a video",
                color = NovaColors.TextSecondary,
                fontSize = 14.sp,
            )
        }
        if (canPlay && !playing) {
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
    }
}

/** Hardware-decoded video surface. Controls are ours, so `useController = false`. */
@Composable
private fun PreviewSurface(player: Player, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setShutterBackgroundColor(android.graphics.Color.BLACK)
                this.player = player
            }
        },
        update = { it.player = player },
    )
}

@Composable
private fun PlaybackBar(
    positionMs: StateFlow<Long>,
    isPlaying: StateFlow<Boolean>,
    durationMs: Long,
    onTogglePlay: () -> Unit,
) {
    val playing by isPlaying.collectAsStateWithLifecycle()
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp)) {
        TimeReadout(positionMs, durationMs, Modifier.align(Alignment.CenterStart))
        IconButton(onClick = onTogglePlay, modifier = Modifier.align(Alignment.Center)) {
            Icon(
                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (playing) "Pause" else "Play",
                modifier = Modifier.size(32.dp),
            )
        }
    }
}

/** The ONLY composable that recomposes at playback rate. */
@Composable
private fun TimeReadout(positionMs: StateFlow<Long>, durationMs: Long, modifier: Modifier = Modifier) {
    val ms by positionMs.collectAsStateWithLifecycle()
    Text(
        text = "${formatClock(ms)} / ${formatClock(durationMs)}",
        color = NovaColors.TextSecondary,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        modifier = modifier,
    )
}

private fun formatClock(ms: Long): String {
    val tenths = ms / 100
    return "%d:%02d.%d".format(tenths / 600, tenths / 10 % 60, tenths % 10)
}

/* ------------------------------ bottom toolbar ------------------------------ */

@Composable
private fun BottomToolbar(
    hasSelection: Boolean,
    canSplit: Boolean,
    canBeatSync: Boolean,
    canUndo: Boolean,
    onMedia: () -> Unit,
    onMusic: () -> Unit,
    onBeatSync: () -> Unit,
    onSplit: () -> Unit,
    onDelete: () -> Unit,
    onUndo: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().background(NovaColors.Surface).padding(vertical = 4.dp),
    ) {
        ToolButton(Icons.Rounded.VideoLibrary, "Media", true, onMedia, Modifier.weight(1f))
        ToolButton(Icons.Rounded.MusicNote, "Music", true, onMusic, Modifier.weight(1f))
        ToolButton(Icons.Rounded.GraphicEq, "Beat sync", canBeatSync, onBeatSync, Modifier.weight(1f))
        ToolButton(Icons.Rounded.ContentCut, "Split", canSplit, onSplit, Modifier.weight(1f))
        ToolButton(Icons.Rounded.Delete, "Delete", hasSelection, onDelete, Modifier.weight(1f))
        ToolButton(Icons.AutoMirrored.Rounded.Undo, "Undo", canUndo, onUndo, Modifier.weight(1f))
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clickable(enabled = enabled, onClick = onClick)
            .alpha(if (enabled) 1f else 0.35f)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = NovaColors.TextPrimary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 10.sp, color = NovaColors.TextPrimary)
    }
}

/* ------------------------------ dialogs ------------------------------ */

@Composable
private fun BeatSyncDialog(onPick: (CutRhythm) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cut to the beat") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Re-cuts your videos so every cut lands on a beat of your song. You can undo it.",
                    fontSize = 13.sp,
                    color = NovaColors.TextSecondary,
                )
                RhythmOption("Every beat (fast)") { onPick(CutRhythm.EVERY_BEAT) }
                RhythmOption("Every 2 beats") { onPick(CutRhythm.EVERY_2_BEATS) }
                RhythmOption("Every bar (4 beats)") { onPick(CutRhythm.EVERY_BAR) }
                RhythmOption("Every 2 bars (slow)") { onPick(CutRhythm.EVERY_2_BARS) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun RhythmOption(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(label) }
}

@Composable
private fun ExportDialogs(export: ExportState, onCancel: () -> Unit, onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    when (export) {
        is ExportState.Idle -> Unit

        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            title = { Text("Exporting…") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LinearProgressIndicator(progress = { export.progress }, modifier = Modifier.fillMaxWidth())
                    Text("${(export.progress * 100).toInt()}%  ·  keep the app open", fontSize = 13.sp, color = NovaColors.TextSecondary)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
        )

        is ExportState.Done -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Saved to your gallery") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(export.savedAs, fontSize = 13.sp)
                    val credits = export.credits
                    if (credits != null) {
                        Text("Music credits. Put these in your video description:", fontSize = 12.sp, color = NovaColors.TextSecondary)
                        Text(credits, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Row {
                    val credits = export.credits
                    if (credits != null) {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(credits)) }) { Text("Copy credits") }
                    }
                    TextButton(onClick = onDismiss) { Text("OK") }
                }
            },
        )

        is ExportState.Failed -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Export failed") },
            text = { Text(export.reason, fontSize = 13.sp) },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
        )
    }
}
