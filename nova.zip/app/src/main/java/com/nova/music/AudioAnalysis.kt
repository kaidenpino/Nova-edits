package com.nova.music

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.io.IOException
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Peak resolution shared by extractor, timeline drawing and beat detection. */
const val PEAKS_PER_SEC = 50

/** MediaCodec decode -> one normalized (0..1) peak per 1/[PEAKS_PER_SEC] s of audio. */
class WaveformExtractor {

    suspend fun extract(file: File, peaksPerSecond: Int = PEAKS_PER_SEC): FloatArray =
        withContext(Dispatchers.Default) {
            val extractor = MediaExtractor().apply { setDataSource(file.path) }
            val trackIndex = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: run { extractor.release(); throw IOException("No audio track in ${file.name}") }

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            // Interleaved 16-bit samples that make up one peak bucket.
            val samplesPerPeak = max(1, sampleRate / peaksPerSecond * channels)
            val peaks = ArrayList<Float>()
            var bucketMax = 0
            var bucketCount = 0

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            try {
                while (!outputDone) {
                    ensureActive()

                    if (!inputDone) {
                        val inIdx = codec.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val buf = codec.getInputBuffer(inIdx)!!
                            val size = extractor.readSampleData(buf, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }

                    val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                    if (outIdx >= 0) {
                        val out = codec.getOutputBuffer(outIdx)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val shorts = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        while (shorts.hasRemaining()) {
                            val s = abs(shorts.get().toInt())
                            if (s > bucketMax) bucketMax = s
                            if (++bucketCount >= samplesPerPeak) {
                                peaks += bucketMax / 32768f
                                bucketMax = 0
                                bucketCount = 0
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            } finally {
                codec.stop()
                codec.release()
                extractor.release()
            }
            peaks.toFloatArray()
        }
}

/**
 * Fallback for tracks with no clear tempo (BeatAnalyzer returns null): flags rises in the envelope that
 * exceed a moving average. Rougher than the fitted grid, but still gives usable markers.
 */
object BeatDetector {

    fun detect(
        peaks: FloatArray,
        peaksPerSec: Int = PEAKS_PER_SEC,
        minGapMs: Long = 250,
        sensitivity: Float = 1.4f,
    ): List<Long> {
        if (peaks.size < 3) return emptyList()

        // Positive envelope change = onset strength.
        val flux = FloatArray(peaks.size) { i -> if (i == 0) 0f else max(0f, peaks[i] - peaks[i - 1]) }

        val window = peaksPerSec               // 1 s moving average
        val beats = mutableListOf<Long>()
        var lastBeatMs = -minGapMs
        var runningSum = 0f

        for (i in flux.indices) {
            runningSum += flux[i]
            if (i >= window) runningSum -= flux[i - window]
            val mean = runningSum / min(i + 1, window)

            val isLocalMax = (i == 0 || flux[i] >= flux[i - 1]) &&
                (i == flux.lastIndex || flux[i] >= flux[i + 1])
            val isOnset = flux[i] > mean * sensitivity && flux[i] > 0.02f && isLocalMax

            val ms = i * 1000L / peaksPerSec
            if (isOnset && ms - lastBeatMs >= minGapMs) {
                beats += ms
                lastBeatMs = ms
            }
        }
        return beats
    }
}
