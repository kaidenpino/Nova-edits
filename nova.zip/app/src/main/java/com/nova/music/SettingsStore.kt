package com.nova.music

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The user's own music-service keys, typed into the app (gear icon in the music sheet), so no rebuild
 * is needed to turn a service on. Stored in the app's private preferences: other apps can't read it,
 * but it is NOT encrypted, so only paste keys that are yours.
 */
@Singleton
class SettingsStore @Inject constructor(@ApplicationContext context: Context) {
    private val prefs = context.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)

    var jamendoClientId: String
        get() = prefs.getString(JAMENDO, "").orEmpty()
        set(value) = prefs.edit().putString(JAMENDO, value.trim()).apply()

    var audiusApiKey: String
        get() = prefs.getString(AUDIUS, "").orEmpty()
        set(value) = prefs.edit().putString(AUDIUS, value.trim()).apply()

    var soundCloudToken: String
        get() = prefs.getString(SOUNDCLOUD, "").orEmpty()
        set(value) = prefs.edit().putString(SOUNDCLOUD, value.trim()).apply()

    private companion object {
        const val JAMENDO = "jamendo_client_id"
        const val AUDIUS = "audius_api_key"
        const val SOUNDCLOUD = "soundcloud_token"
    }
}
