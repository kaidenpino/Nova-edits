package com.nova.music

import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request

/* =====================================================================================
 *  Tiny HTTP + JSON helpers.
 *
 *  Responses are read as a loose JSON tree instead of strict data classes on purpose: these are
 *  third-party APIs I could not call while writing this, so every field is treated as optional and a
 *  missing or renamed field degrades gracefully (a track loses its artwork) instead of failing the
 *  whole search.
 * ===================================================================================== */

class HttpJson(private val client: OkHttpClient) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): JsonElement =
        withContext(Dispatchers.IO) {
            val request = Request.Builder().url(url).apply {
                headers.forEach { (k, v) -> header(k, v) }
            }.build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
                val text = response.body?.string() ?: throw IOException("empty response")
                json.parseToJsonElement(text)
            }
        }
}

internal fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
internal fun JsonObject.long(key: String): Long? = (this[key] as? JsonPrimitive)?.longOrNull
internal fun JsonObject.bool(key: String): Boolean? = (this[key] as? JsonPrimitive)?.booleanOrNull
internal fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject
internal fun JsonObject.array(key: String): JsonArray? = this[key] as? JsonArray

private const val APP_NAME = "Nova"

/** "http://creativecommons.org/licenses/by-nc-sa/3.0/" -> "CC BY-NC-SA 3.0". */
internal fun ccName(url: String): String {
    val m = Regex("licenses/([a-z-]+)/([0-9.]+)").find(url) ?: return "Creative Commons"
    return "CC ${m.groupValues[1].uppercase()} ${m.groupValues[2]}"
}

/* =====================================================================================
 *  JAMENDO: free, Creative-Commons catalogue. Needs a free client id (devportal.jamendo.com).
 *  Each result says whether downloading is allowed, which is what we use as the export permission.
 * ===================================================================================== */

class JamendoProvider(private val http: HttpJson, private val settings: SettingsStore) : MusicProvider {
    override val id = ProviderId.JAMENDO
    override val name = "Jamendo"

    override suspend fun search(query: String, limit: Int): List<Track> {
        val clientId = settings.jamendoClientId
        if (clientId.isBlank()) {
            throw MissingConfigException("Jamendo: add your free key in settings (gear) to search free music.")
        }
        val url = "https://api.jamendo.com/v3.0/tracks/".toHttpUrl().newBuilder()
            .addQueryParameter("client_id", clientId)
            .addQueryParameter("format", "json")
            .addQueryParameter("limit", limit.toString())
            .addQueryParameter("search", query)
            .addQueryParameter("audioformat", "mp32")
            .addQueryParameter("imagesize", "200")
            .build()

        val root = http.get(url.toString()) as? JsonObject ?: return emptyList()
        val results = root.array("results") ?: return emptyList()
        return results.mapNotNull { element ->
            val o = element as? JsonObject ?: return@mapNotNull null
            val trackId = o.string("id") ?: return@mapNotNull null
            val allowed = o.bool("audiodownload_allowed") ?: false
            Track(
                id = trackId,
                provider = id,
                title = o.string("name") ?: "Untitled",
                artist = o.string("artist_name") ?: "Unknown artist",
                durationMs = (o.long("duration") ?: 0L) * 1000L,
                artworkUrl = o.string("image"),
                permalinkUrl = o.string("shareurl"),
                license = o.string("license_ccurl")?.let(::ccName),
                exportRights = if (allowed) ExportRights.EXPORT_OK else ExportRights.PREVIEW_ONLY,
                streamUrl = o.string("audio"),
                downloadUrl = o.string("audiodownload"),
            )
        }
    }

    override suspend fun resolveStream(track: Track): StreamSource {
        val canDownload = track.exportRights == ExportRights.EXPORT_OK
        val url = (if (canDownload) track.downloadUrl else null)?.takeIf { it.isNotBlank() }
            ?: track.streamUrl?.takeIf { it.isNotBlank() }
            ?: throw IOException("No audio link for this track")
        return StreamSource(url = url, downloadable = canDownload)
    }
}

/* =====================================================================================
 *  AUDIUS: open, artist-uploaded music. Audius now recommends a (free) API key; without one the
 *  request is sent with just an app name and may be rate-limited or refused.
 *  Only tracks the artist marked downloadable count as usable in a video.
 * ===================================================================================== */

class AudiusProvider(private val http: HttpJson, private val settings: SettingsStore) : MusicProvider {
    override val id = ProviderId.AUDIUS
    override val name = "Audius"

    private fun headers(): Map<String, String> =
        settings.audiusApiKey.takeIf { it.isNotBlank() }?.let { mapOf("Authorization" to "Bearer $it") } ?: emptyMap()

    override suspend fun search(query: String, limit: Int): List<Track> {
        val url = "$BASE/tracks/search".toHttpUrl().newBuilder()
            .addQueryParameter("query", query)
            .addQueryParameter("app_name", APP_NAME)
            .addQueryParameter("limit", limit.toString())
            .build()

        val root = http.get(url.toString(), headers()) as? JsonObject ?: return emptyList()
        val data = root.array("data") ?: return emptyList()
        return data.mapNotNull { element ->
            val o = element as? JsonObject ?: return@mapNotNull null
            val trackId = o.string("id") ?: return@mapNotNull null
            val downloadable = o.bool("is_downloadable") ?: o.bool("downloadable") ?: false
            val artwork = o.obj("artwork")
            val permalink = o.string("permalink")
            Track(
                id = trackId,
                provider = id,
                title = o.string("title") ?: "Untitled",
                artist = o.obj("user")?.string("name") ?: "Unknown artist",
                durationMs = (o.long("duration") ?: 0L) * 1000L,
                artworkUrl = artwork?.string("150x150") ?: artwork?.string("480x480"),
                permalinkUrl = permalink?.let { if (it.startsWith("http")) it else "https://audius.co$it" },
                license = o.string("license"),
                exportRights = if (downloadable) ExportRights.EXPORT_OK else ExportRights.PREVIEW_ONLY,
            )
        }
    }

    override suspend fun resolveStream(track: Track): StreamSource {
        val fallback = "$BASE/tracks/${track.id}/stream?app_name=$APP_NAME"
        // no_redirect=true makes the API answer with the final audio URL as JSON instead of a redirect,
        // so the (optional) auth header is applied to the lookup.
        val resolved = runCatching {
            val root = http.get("$fallback&no_redirect=true", headers()) as? JsonObject
            root?.string("data")
        }.getOrNull()
        return StreamSource(
            url = resolved?.takeIf { it.startsWith("http") } ?: fallback,
            downloadable = track.exportRights == ExportRights.EXPORT_OK,
        )
    }

    private companion object {
        const val BASE = "https://api.audius.co/v1"
    }
}

/* =====================================================================================
 *  SOUNDCLOUD: SoundCloud's own docs say API credentials need a paid Artist Pro account, so this is
 *  opt-in: it only works if you paste an access token you obtained yourself. Only downloadable or
 *  Creative-Commons tracks count as usable in a video.
 * ===================================================================================== */

class SoundCloudProvider(private val http: HttpJson, private val settings: SettingsStore) : MusicProvider {
    override val id = ProviderId.SOUNDCLOUD
    override val name = "SoundCloud"

    private fun headers(): Map<String, String> {
        val token = settings.soundCloudToken
        if (token.isBlank()) {
            throw MissingConfigException("SoundCloud: needs your own API token in settings (requires a SoundCloud Artist Pro account).")
        }
        return mapOf("Authorization" to "OAuth $token")
    }

    override suspend fun search(query: String, limit: Int): List<Track> {
        val auth = headers()
        val url = "https://api.soundcloud.com/tracks".toHttpUrl().newBuilder()
            .addQueryParameter("q", query)
            .addQueryParameter("limit", limit.toString())
            .addQueryParameter("access", "playable")
            .build()

        val root = http.get(url.toString(), auth) as? JsonArray ?: return emptyList()
        return root.mapNotNull { element ->
            val o = element as? JsonObject ?: return@mapNotNull null
            val trackId = o.string("id") ?: return@mapNotNull null
            val license = o.string("license")
            val usable = (o.bool("downloadable") ?: false) || license?.startsWith("cc", ignoreCase = true) == true
            Track(
                id = trackId,
                provider = id,
                title = o.string("title") ?: "Untitled",
                artist = o.obj("user")?.string("username") ?: "Unknown artist",
                durationMs = o.long("duration") ?: 0L,            // SoundCloud reports milliseconds
                artworkUrl = o.string("artwork_url"),
                permalinkUrl = o.string("permalink_url"),
                license = license,
                exportRights = if (usable) ExportRights.EXPORT_OK else ExportRights.PREVIEW_ONLY,
            )
        }
    }

    override suspend fun resolveStream(track: Track): StreamSource {
        val root = http.get("https://api.soundcloud.com/tracks/${track.id}/streams", headers()) as? JsonObject
        val url = root?.string("http_mp3_128_url") ?: root?.string("preview_mp3_128_url")
            ?: throw IOException("No playable stream for this track")
        return StreamSource(url = url, downloadable = track.exportRights == ExportRights.EXPORT_OK)
    }
}
