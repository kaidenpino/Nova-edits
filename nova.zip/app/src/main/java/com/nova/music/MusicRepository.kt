package com.nova.music

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import com.nova.beat.BeatAnalyzer
import com.nova.beat.BeatGrid
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.File
import java.io.IOException
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/* =====================================================================================
 *  DOMAIN MODEL
 * ===================================================================================== */

enum class ProviderId { SOUNDCLOUD, JAMENDO, LOCAL }

/**
 * Whether audio from this track may be baked into an exported video.
 * Decided PER TRACK from the provider's license/permission flags, never assumed.
 */
enum class ExportRights { EXPORT_OK, PREVIEW_ONLY }

data class Track(
    val id: String,
    val provider: ProviderId,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val artworkUrl: String?,
    val permalinkUrl: String?,      // needed for attribution
    val license: String?,           // e.g. "cc-by", "all-rights-reserved"
    val exportRights: ExportRights,
)

/** A resolved audio location. `downloadable` mirrors the provider's permission, not our wishes. */
data class StreamSource(
    val url: String,
    val headers: Map<String, String> = emptyMap(),
    val downloadable: Boolean,
)

/** Everything the timeline needs about a cached track. */
/**
 * [grid] is the fitted tempo/beat grid (null when the track has no clear pulse, in which case
 * [beatsMs] falls back to the v1 onset detector). Check [BeatGrid.confidence] before promising "beat-synced".
 */
data class LocalAudio(
    val track: Track,
    val file: File,
    val peaks: FloatArray,
    val beatsMs: List<Long>,
    val grid: BeatGrid? = null,
)

sealed interface CacheState {
    data class Downloading(val fraction: Float) : CacheState
    data object Analyzing : CacheState
    data class Ready(val audio: LocalAudio) : CacheState
    data class Failed(val reason: Reason, val cause: Throwable? = null) : CacheState

    enum class Reason { NOT_EXPORTABLE, NETWORK, DECODE }
}

/* =====================================================================================
 *  PROVIDER ABSTRACTION: one implementation per catalog
 * ===================================================================================== */

interface MusicProvider {
    val id: ProviderId
    suspend fun search(query: String, limit: Int = 20, offset: Int = 0): List<Track>
    suspend fun resolveStream(track: Track): StreamSource
}

/* ---------- SoundCloud (official API; verify current endpoints/terms in their docs) ---------- */

interface SoundCloudApi {
    @GET("tracks")
    suspend fun search(
        @Query("q") query: String,
        @Query("limit") limit: Int,
        @Query("offset") offset: Int,
        @Query("access") access: String = "playable",
    ): List<ScTrack>

    @GET("tracks/{id}/streams")
    suspend fun streams(@Path("id") id: Long): ScStreams
}

@Serializable
data class ScUser(val username: String = "")

@Serializable
data class ScTrack(
    val id: Long,
    val title: String = "",
    val duration: Long = 0,
    @SerialName("artwork_url") val artworkUrl: String? = null,
    @SerialName("permalink_url") val permalinkUrl: String? = null,
    val license: String? = null,
    val downloadable: Boolean = false,
    val user: ScUser = ScUser(),
)

@Serializable
data class ScStreams(
    @SerialName("http_mp3_128_url") val mp3: String? = null,
    @SerialName("preview_mp3_128_url") val preview: String? = null,
)

/**
 * Auth is handled by an OkHttp interceptor that attaches a short-lived token obtained from
 * YOUR backend. Never embed a client secret in the APK.
 */
class SoundCloudProvider(private val api: SoundCloudApi) : MusicProvider {
    override val id = ProviderId.SOUNDCLOUD

    override suspend fun search(query: String, limit: Int, offset: Int): List<Track> =
        api.search(query, limit, offset).map { sc ->
            Track(
                id = sc.id.toString(),
                provider = id,
                title = sc.title,
                artist = sc.user.username,
                durationMs = sc.duration,
                artworkUrl = sc.artworkUrl,
                permalinkUrl = sc.permalinkUrl,
                license = sc.license,
                // Only tracks the rights-holder allows to be downloaded, or CC-licensed ones,
                // may be baked into exports. Everything else is audition-only.
                exportRights = if (sc.downloadable || sc.license?.startsWith("cc") == true)
                    ExportRights.EXPORT_OK else ExportRights.PREVIEW_ONLY,
            )
        }

    override suspend fun resolveStream(track: Track): StreamSource {
        val streams = api.streams(track.id.toLong())
        val url = streams.mp3 ?: streams.preview ?: throw IOException("No playable stream for ${track.id}")
        return StreamSource(url = url, downloadable = track.exportRights == ExportRights.EXPORT_OK)
    }
}

// JamendoProvider, AudiusProvider, LocalFilesProvider ... implement MusicProvider the same way.

/* =====================================================================================
 *  REPOSITORY
 * ===================================================================================== */

class MusicRepository(
    private val providers: List<MusicProvider>,
    private val http: OkHttpClient,
    private val musicDir: File,                  // e.g. context.filesDir/music
    private val waveforms: WaveformExtractor = WaveformExtractor(),
    private val io: CoroutineDispatcher = Dispatchers.IO,
) {
    init { musicDir.mkdirs() }

    /**
     * Fans out to every provider in parallel and emits the accumulated list each time one answers,
     * so the UI fills in progressively instead of waiting for the slowest catalog.
     * One provider failing never breaks search.
     */
    fun search(query: String): Flow<List<Track>> = channelFlow {
        val acc = mutableListOf<Track>()
        val lock = Mutex()
        providers.forEach { provider ->
            launch {
                val results = runCatching { provider.search(query) }.getOrDefault(emptyList())
                lock.withLock {
                    acc += results
                    send(acc.toList())
                }
            }
        }
    }

    /** Stream URL for AUDITIONING (feed to ExoPlayer, ideally through a SimpleCache data source). */
    suspend fun previewSource(track: Track): StreamSource =
        provider(track).resolveStream(track)

    /**
     * Downloads (if needed), analyzes, and returns a timeline-ready asset.
     * Emits progress; the final emission is Ready or Failed.
     */
    fun cacheForTimeline(track: Track): Flow<CacheState> = channelFlow {
        if (track.exportRights != ExportRights.EXPORT_OK) {
            send(CacheState.Failed(CacheState.Reason.NOT_EXPORTABLE))
            return@channelFlow
        }

        val target = File(musicDir, "${track.provider.name}_${track.id}.audio")

        // 1) Download (skipped when already cached)
        if (!target.exists() || target.length() == 0L) {
            val source = provider(track).resolveStream(track)
            if (!source.downloadable) {
                send(CacheState.Failed(CacheState.Reason.NOT_EXPORTABLE))
                return@channelFlow
            }
            val ok = downloadAtomically(source, target) { send(CacheState.Downloading(it)) }
            if (!ok) {
                send(CacheState.Failed(CacheState.Reason.NETWORK))
                return@channelFlow
            }
        }

        // 2) Analyze: waveform peaks + beat markers (both off the main thread)
        send(CacheState.Analyzing)
        try {
            val peaks = waveforms.extract(target)
            // Grid fitting is CPU-bound (a few million multiply-adds for a 3-min song): keep it off the IO pool.
            val grid = withContext(Dispatchers.Default) { BeatAnalyzer.analyze(peaks) }
            val beats = grid?.beatsMs ?: BeatDetector.detect(peaks)
            send(CacheState.Ready(LocalAudio(track, target, peaks, beats, grid)))
        } catch (t: Throwable) {
            target.delete()   // corrupt download: don't keep it
            send(CacheState.Failed(CacheState.Reason.DECODE, t))
        }
    }.flowOn(io)

    /* ---------------------------- internals ---------------------------- */

    private fun provider(track: Track) =
        providers.first { it.id == track.provider }

    /**
     * Writes to `<file>.part` and renames on success, so a killed download never leaves a
     * half-written file that later looks like a valid cache hit.
     */
    private suspend fun downloadAtomically(
        source: StreamSource,
        target: File,
        onProgress: suspend (Float) -> Unit,
    ): Boolean = withContext(io) {
        val part = File(target.parentFile, target.name + ".part")
        try {
            val request = Request.Builder().url(source.url).apply {
                source.headers.forEach { (k, v) -> header(k, v) }
            }.build()

            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val body = response.body ?: return@withContext false
                val total = body.contentLength().takeIf { it > 0 }
                part.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    body.byteStream().use { input ->
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            read += n
                            if (total != null) onProgress(read.toFloat() / total)
                        }
                    }
                }
            }
            part.renameTo(target)
        } catch (e: IOException) {
            part.delete()
            false
        }
    }
}

/* =====================================================================================
 *  WAVEFORM EXTRACTION: MediaCodec decode -> peak envelope
 * ===================================================================================== */

/** Peak resolution shared by extractor, timeline drawing and beat detection. */
const val PEAKS_PER_SEC = 50

class WaveformExtractor {

    /** Returns one normalized (0..1) peak per 1/[peaksPerSecond] s of audio. */
    suspend fun extract(file: File, peaksPerSecond: Int = PEAKS_PER_SEC): FloatArray =
        withContext(Dispatchers.Default) {
            val extractor = MediaExtractor().apply { setDataSource(file.path) }
            val trackIndex = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: run { extractor.release(); throw IOException("No audio track in ${file.name}") }

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            // Interleaved 16-bit samples that make up one peak bucket.
            val samplesPerPeak = max(1, sampleRate / peaksPerSecond * channels)
            val peaks = ArrayList<Float>()
            var bucketMax = 0
            var bucketCount = 0

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            try {
                while (!outputDone) {
                    ensureActive()

                    if (!inputDone) {
                        val inIdx = codec.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val buf = codec.getInputBuffer(inIdx)!!
                            val size = extractor.readSampleData(buf, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }

                    val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                    if (outIdx >= 0) {
                        val out = codec.getOutputBuffer(outIdx)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val shorts = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        while (shorts.hasRemaining()) {
                            val s = abs(shorts.get().toInt())
                            if (s > bucketMax) bucketMax = s
                            if (++bucketCount >= samplesPerPeak) {
                                peaks += bucketMax / 32768f
                                bucketMax = 0
                                bucketCount = 0
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            } finally {
                codec.stop()
                codec.release()
                extractor.release()
            }
            peaks.toFloatArray()
        }
}

/* =====================================================================================
 *  BEAT DETECTION (v1): onset detection on the amplitude envelope
 * ===================================================================================== */

/**
 * Cheap and dependency-free: flags rises in the envelope that exceed a moving average.
 * Good enough for beat markers and snap targets. Upgrade path: STFT spectral flux per band,
 * tempo estimation via autocorrelation, and a fitted beat grid to fill missed onsets.
 */
object BeatDetector {

    fun detect(
        peaks: FloatArray,
        peaksPerSec: Int = PEAKS_PER_SEC,
        minGapMs: Long = 250,
        sensitivity: Float = 1.4f,
    ): List<Long> {
        if (peaks.size < 3) return emptyList()

        // Positive envelope change = onset strength.
        val flux = FloatArray(peaks.size) { i -> if (i == 0) 0f else max(0f, peaks[i] - peaks[i - 1]) }

        val window = peaksPerSec               // 1 s moving average
        val beats = mutableListOf<Long>()
        var lastBeatMs = -minGapMs
        var runningSum = 0f

        for (i in flux.indices) {
            runningSum += flux[i]
            if (i >= window) runningSum -= flux[i - window]
            val mean = runningSum / min(i + 1, window)

            val isLocalMax = (i == 0 || flux[i] >= flux[i - 1]) &&
                (i == flux.lastIndex || flux[i] >= flux[i + 1])
            val isOnset = flux[i] > mean * sensitivity && flux[i] > 0.02f && isLocalMax

            val ms = i * 1000L / peaksPerSec
            if (isOnset && ms - lastBeatMs >= minGapMs) {
                beats += ms
                lastBeatMs = ms
            }
        }
        return beats
    }
}
