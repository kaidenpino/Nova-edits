package com.nova.music

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.nova.beat.BeatAnalyzer
import com.nova.beat.BeatGrid
import java.io.File
import java.io.IOException
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/* =====================================================================================
 *  MODEL
 * ===================================================================================== */

enum class ProviderId { JAMENDO, AUDIUS, SOUNDCLOUD, LOCAL }

/**
 * Whether audio from this track may be baked into an exported video. Decided PER TRACK from the
 * catalogue's own permission flags, never assumed: PREVIEW_ONLY tracks can be auditioned but not used.
 */
enum class ExportRights { EXPORT_OK, PREVIEW_ONLY }

data class Track(
    val id: String,
    val provider: ProviderId,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val artworkUrl: String?,
    val permalinkUrl: String?,      // needed for attribution
    val license: String?,           // e.g. "CC BY-NC-SA 3.0"
    val exportRights: ExportRights,
    val streamUrl: String? = null,  // some catalogues hand these out with the search result
    val downloadUrl: String? = null,
)

/** Attribution line for the export description (required by CC-BY style licences). */
fun Track.creditLine(): String = buildString {
    append('"').append(title).append("\" by ").append(artist)
    license?.let { append(" [").append(it).append(']') }
    permalinkUrl?.let { append(" - ").append(it) }
}

/** A resolved audio location. `downloadable` mirrors the provider's permission, not our wishes. */
data class StreamSource(
    val url: String,
    val headers: Map<String, String> = emptyMap(),
    val downloadable: Boolean,
)

/** Everything the timeline needs about a song that is on disk and analysed. */
data class LocalAudio(
    val track: Track,
    val file: File,
    val peaks: FloatArray,
    val beatsMs: List<Long>,
    /** The fitted tempo/beat grid, or null when the song has no clear pulse (beats then come from the rougher detector). */
    val grid: BeatGrid? = null,
)

sealed interface CacheState {
    data class Downloading(val fraction: Float) : CacheState
    data object Analyzing : CacheState
    data class Ready(val audio: LocalAudio) : CacheState
    data class Failed(val reason: Reason, val cause: Throwable? = null) : CacheState

    enum class Reason { NOT_EXPORTABLE, NETWORK, DECODE }
}

/** Accumulated results so far, plus short human-readable notes ("add your Jamendo key", "couldn't reach X"). */
data class SearchUpdate(val tracks: List<Track>, val notices: List<String>)

/** Thrown by a provider that needs a key the user hasn't entered yet. The message is shown as-is. */
class MissingConfigException(message: String) : Exception(message)

/* =====================================================================================
 *  PROVIDER ABSTRACTION: one implementation per catalogue (see MusicProviders.kt)
 * ===================================================================================== */

interface MusicProvider {
    val id: ProviderId
    val name: String
    suspend fun search(query: String, limit: Int = 25): List<Track>
    suspend fun resolveStream(track: Track): StreamSource
}

/* =====================================================================================
 *  REPOSITORY
 * ===================================================================================== */

class MusicRepository(
    context: Context,
    private val providers: List<MusicProvider>,
    private val http: OkHttpClient,
    private val waveforms: WaveformExtractor = WaveformExtractor(),
) {
    private val resolver = context.applicationContext.contentResolver
    private val musicDir = File(context.applicationContext.filesDir, "music").apply { mkdirs() }

    /**
     * Asks every catalogue in parallel and emits the accumulated list each time one answers, so results
     * appear as soon as the fastest source responds. One source failing never breaks the search.
     */
    fun search(query: String): Flow<SearchUpdate> = channelFlow {
        val tracks = mutableListOf<Track>()
        val notices = mutableListOf<String>()
        val lock = Mutex()
        for (provider in providers) {
            launch {
                val outcome: Result<List<Track>> = try {
                    Result.success(provider.search(query))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Result.failure(e)
                }
                lock.withLock {
                    outcome.onSuccess { tracks += it }
                    outcome.onFailure { e ->
                        notices += if (e is MissingConfigException) {
                            e.message.orEmpty()
                        } else {
                            "Couldn't reach ${provider.name}" + (e.message?.let { " ($it)" } ?: "")
                        }
                    }
                    send(SearchUpdate(tracks.toList(), notices.toList()))
                }
            }
        }
    }

    /** Stream URL for AUDITIONING (feed to ExoPlayer). Works for every track, including preview-only ones. */
    suspend fun previewSource(track: Track): StreamSource = providerFor(track).resolveStream(track)

    /**
     * Downloads (if needed), analyses and returns a timeline-ready song. Emits progress; the final
     * emission is Ready or Failed. Tracks that are not EXPORT_OK are refused here, so a preview-only
     * track can never end up in an export even by accident.
     */
    fun cacheForTimeline(track: Track): Flow<CacheState> = channelFlow {
        if (track.exportRights != ExportRights.EXPORT_OK) {
            send(CacheState.Failed(CacheState.Reason.NOT_EXPORTABLE))
            return@channelFlow
        }

        val safeName = "${track.provider.name}_${track.id}".replace(Regex("[^A-Za-z0-9_-]"), "_")
        val target = File(musicDir, "$safeName.audio")

        // 1) Download (skipped when already cached)
        if (!target.exists() || target.length() == 0L) {
            val source = try {
                providerFor(track).resolveStream(track)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                send(CacheState.Failed(CacheState.Reason.NETWORK, e))
                return@channelFlow
            }
            if (!source.downloadable) {
                send(CacheState.Failed(CacheState.Reason.NOT_EXPORTABLE))
                return@channelFlow
            }
            val ok = downloadAtomically(source, target) { send(CacheState.Downloading(it)) }
            if (!ok) {
                send(CacheState.Failed(CacheState.Reason.NETWORK))
                return@channelFlow
            }
        }

        // 2) Analyse: waveform peaks + beat grid
        send(CacheState.Analyzing)
        try {
            send(CacheState.Ready(analyze(track, target)))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            target.delete()                     // corrupt download: don't keep it
            send(CacheState.Failed(CacheState.Reason.DECODE, e))
        }
    }.flowOn(Dispatchers.IO)

    /** A song from the phone's own storage: copied into the app, then analysed like any other. */
    suspend fun importLocal(uri: Uri): LocalAudio = withContext(Dispatchers.IO) {
        val displayName = runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull() ?: "My song"

        val id = UUID.randomUUID().toString()
        val file = File(musicDir, "LOCAL_$id.audio")
        try {
            resolver.openInputStream(uri)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IOException("Couldn't open that file")

            val peaks = waveforms.extract(file)
            val track = Track(
                id = id,
                provider = ProviderId.LOCAL,
                title = displayName.substringBeforeLast('.'),
                artist = "My music",
                durationMs = peaks.size * 1000L / PEAKS_PER_SEC,
                artworkUrl = null,
                permalinkUrl = null,
                license = null,
                exportRights = ExportRights.EXPORT_OK,     // the user's own file: their responsibility
            )
            analyzePeaks(track, file, peaks)
        } catch (e: Exception) {
            file.delete()
            throw e
        }
    }

    /* ---------------------------- internals ---------------------------- */

    private fun providerFor(track: Track): MusicProvider =
        providers.firstOrNull { it.id == track.provider } ?: throw IOException("No source for ${track.provider}")

    private suspend fun analyze(track: Track, file: File): LocalAudio =
        analyzePeaks(track, file, waveforms.extract(file))

    private suspend fun analyzePeaks(track: Track, file: File, peaks: FloatArray): LocalAudio {
        // Grid fitting is CPU-bound (a few million multiply-adds for a 3-minute song): keep it off the IO pool.
        val grid = withContext(Dispatchers.Default) { BeatAnalyzer.analyze(peaks) }
        val beats = grid?.beatsMs ?: BeatDetector.detect(peaks)
        return LocalAudio(track, file, peaks, beats, grid)
    }

    /**
     * Writes to `<file>.part` and renames on success, so a killed download never leaves a half-written
     * file that later looks like a valid cache hit.
     */
    private suspend fun downloadAtomically(
        source: StreamSource,
        target: File,
        onProgress: suspend (Float) -> Unit,
    ): Boolean = withContext(Dispatchers.IO) {
        val part = File(target.parentFile, target.name + ".part")
        try {
            val request = Request.Builder().url(source.url).apply {
                source.headers.forEach { (k, v) -> header(k, v) }
            }.build()

            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val body = response.body ?: return@withContext false
                val total = body.contentLength().takeIf { it > 0 }
                part.outputStream().use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var read = 0L
                    body.byteStream().use { input ->
                        while (true) {
                            ensureActive()
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            read += n
                            if (total != null) onProgress(read.toFloat() / total)
                        }
                    }
                }
            }
            part.renameTo(target)
        } catch (e: IOException) {
            part.delete()
            false
        }
    }
}
