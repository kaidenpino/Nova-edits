package com.nova.music

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.nova.ui.NovaColors

/**
 * The music browser. Two ways to get a song onto the timeline:
 *  1. "Add a song from my phone": always works, any audio file.
 *  2. Search the catalogues you've switched on (gear icon). Only tracks the catalogue marks as usable
 *     in videos get a "Use" button; the rest can be auditioned but not added.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicSheet(
    onDismiss: () -> Unit,
    onUse: (LocalAudio) -> Unit,
    vm: MusicViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val focus = LocalFocusManager.current
    var showSettings by remember { mutableStateOf(false) }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLocal(uri, onUse)
    }

    DisposableEffect(Unit) { onDispose { vm.stopPreview() } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = NovaColors.Surface,
        contentColor = NovaColors.TextPrimary,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(horizontal = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Music", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Rounded.Settings, contentDescription = "Music sources", tint = NovaColors.TextSecondary)
                }
            }
            Spacer(Modifier.height(8.dp))

            OutlinedButton(
                onClick = { pickAudio.launch(arrayOf("audio/*")) },
                enabled = !state.importing,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (state.importing) "Reading song…" else "Add a song from my phone")
            }
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = state.query,
                onValueChange = vm::onQueryChange,
                singleLine = true,
                placeholder = { Text("Search free music") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (state.searching) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); vm.search() }),
                modifier = Modifier.fillMaxWidth(),
            )

            state.notices.forEach { notice ->
                Text(notice, color = NovaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            state.message?.let {
                Text(it, color = NovaColors.Danger, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }

            if (state.results.isEmpty() && !state.searching) {
                Text(
                    "Search for music above, or add a song from your phone.\n\n" +
                        "\"Preview only\" tracks can be played here, but their owners haven't cleared them for use in videos, so they can't be added.",
                    color = NovaColors.TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 16.dp),
                )
            }

            LazyColumn(Modifier.weight(1f)) {
                items(state.results, key = { "${it.provider}:${it.id}" }) { track ->
                    TrackRow(
                        track = track,
                        previewing = state.previewingId == track.id,
                        progress = state.progress[track.id],
                        onTogglePreview = { vm.togglePreview(track) },
                        onUse = { vm.use(track, onUse) },
                    )
                }
            }
        }
    }

    if (showSettings) SourcesDialog(settings = vm.settings, onClose = { showSettings = false })
}

@Composable
private fun TrackRow(
    track: Track,
    previewing: Boolean,
    progress: Float?,
    onTogglePreview: () -> Unit,
    onUse: () -> Unit,
) {
    val usable = track.exportRights == ExportRights.EXPORT_OK
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model = track.artworkUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NovaColors.SurfaceHigh),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
            )
            Text(
                "${track.artist} · ${formatDuration(track.durationMs)}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = NovaColors.TextSecondary,
            )
            Text(
                if (usable) (track.license ?: "Free to use") else "Preview only",
                fontSize = 11.sp,
                color = if (usable) NovaColors.Accent else NovaColors.TextSecondary,
            )
        }
        IconButton(onClick = onTogglePreview) {
            Icon(
                if (previewing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (previewing) "Stop preview" else "Preview",
            )
        }
        if (progress != null) {
            CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
        } else if (usable) {
            Button(onClick = onUse, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Use") }
        }
    }
}

@Composable
private fun SourcesDialog(settings: SettingsStore, onClose: () -> Unit) {
    var jamendo by remember { mutableStateOf(settings.jamendoClientId) }
    var audius by remember { mutableStateOf(settings.audiusApiKey) }
    var soundcloud by remember { mutableStateOf(settings.soundCloudToken) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Music sources") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Text(
                    "Songs from your phone always work. To search a catalogue, paste your own key:",
                    fontSize = 13.sp,
                )
                KeyField("Jamendo client ID (free: devportal.jamendo.com)", jamendo) { jamendo = it }
                KeyField("Audius API key (free, optional)", audius) { audius = it }
                KeyField("SoundCloud token (needs an Artist Pro account)", soundcloud) { soundcloud = it }
                Text(
                    "Keys are saved on this phone only. They are not encrypted, so only paste keys that are yours.",
                    fontSize = 11.sp,
                    color = NovaColors.TextSecondary,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                settings.jamendoClientId = jamendo
                settings.audiusApiKey = audius
                settings.soundCloudToken = soundcloud
                onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}

@Composable
private fun KeyField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
}

/** 3:07 */
internal fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
