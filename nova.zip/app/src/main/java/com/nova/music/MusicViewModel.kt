package com.nova.music

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MusicUiState(
    val query: String = "",
    val results: List<Track> = emptyList(),
    val searching: Boolean = false,
    val notices: List<String> = emptyList(),
    /** trackId -> 0..1 while that track is being downloaded and analysed. */
    val progress: Map<String, Float> = emptyMap(),
    val previewingId: String? = null,
    val importing: Boolean = false,
    val message: String? = null,
)

@HiltViewModel
class MusicViewModel @Inject constructor(
    @ApplicationContext appContext: Context,
    private val repo: MusicRepository,
    val settings: SettingsStore,
) : ViewModel() {

    private val _state = MutableStateFlow(MusicUiState())
    val state: StateFlow<MusicUiState> = _state.asStateFlow()

    // A separate little player just for auditioning search results (the editor has its own engine).
    private val audition: ExoPlayer = ExoPlayer.Builder(appContext).build()
    private var searchJob: Job? = null

    init {
        audition.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) stopPreview()
            }

            override fun onPlayerError(error: PlaybackException) {
                stopPreview()
                say("Couldn't play that preview.")
            }
        })
    }

    private fun say(text: String) = _state.update { it.copy(message = text) }

    private fun setProgress(trackId: String, value: Float?) = _state.update { s ->
        s.copy(progress = if (value == null) s.progress - trackId else s.progress + (trackId to value))
    }

    fun onQueryChange(text: String) = _state.update { it.copy(query = text) }

    fun clearMessage() = _state.update { it.copy(message = null) }

    fun search() {
        val query = _state.value.query.trim()
        if (query.isEmpty()) return
        stopPreview()
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _state.update { it.copy(searching = true, results = emptyList(), notices = emptyList(), message = null) }
            try {
                repo.search(query).collect { update ->
                    _state.update { it.copy(results = update.tracks, notices = update.notices) }
                }
            } finally {
                _state.update { it.copy(searching = false) }
            }
        }
    }

    /** Tap once to hear a result, tap again to stop. Works for every track, including preview-only ones. */
    fun togglePreview(track: Track) {
        if (_state.value.previewingId == track.id) { stopPreview(); return }
        stopPreview()
        _state.update { it.copy(previewingId = track.id) }
        viewModelScope.launch {
            try {
                val source = repo.previewSource(track)
                if (_state.value.previewingId != track.id) return@launch      // user tapped something else meanwhile
                audition.setMediaItem(MediaItem.fromUri(source.url))
                audition.prepare()
                audition.play()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                stopPreview()
                say("Couldn't play that preview.")
            }
        }
    }

    fun stopPreview() {
        audition.stop()
        audition.clearMediaItems()
        _state.update { it.copy(previewingId = null) }
    }

    /** Download + analyse a usable track, then hand it to the editor. */
    fun use(track: Track, onReady: (LocalAudio) -> Unit) {
        if (_state.value.progress.containsKey(track.id)) return
        stopPreview()
        setProgress(track.id, 0f)
        viewModelScope.launch {
            try {
                repo.cacheForTimeline(track).collect { st ->
                    when (st) {
                        is CacheState.Downloading -> setProgress(track.id, st.fraction * 0.85f)
                        is CacheState.Analyzing -> setProgress(track.id, 0.92f)
                        is CacheState.Ready -> { setProgress(track.id, null); onReady(st.audio) }
                        is CacheState.Failed -> {
                            setProgress(track.id, null)
                            say(
                                when (st.reason) {
                                    CacheState.Reason.NOT_EXPORTABLE -> "That track isn't cleared for use in videos."
                                    CacheState.Reason.NETWORK -> "Download failed. Check your connection and try again."
                                    CacheState.Reason.DECODE -> "Couldn't read that audio file."
                                }
                            )
                        }
                    }
                }
            } finally {
                setProgress(track.id, null)
            }
        }
    }

    /** A song from the phone's own storage. */
    fun importLocal(uri: Uri, onReady: (LocalAudio) -> Unit) {
        stopPreview()
        _state.update { it.copy(importing = true, message = null) }
        viewModelScope.launch {
            try {
                onReady(repo.importLocal(uri))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say("Couldn't read that audio file.")
            } finally {
                _state.update { it.copy(importing = false) }
            }
        }
    }

    override fun onCleared() {
        audition.release()
    }
}
