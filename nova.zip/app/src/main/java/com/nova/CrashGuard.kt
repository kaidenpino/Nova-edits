package com.nova

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Saves the stack trace of any crash to a file, so the NEXT launch can show it on screen.
 * Installed in NovaApp.attachBaseContext, i.e. before Hilt or anything else starts.
 */
object CrashLog {
    private const val FILE_NAME = "last_crash.txt"

    fun install(filesDir: File) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                File(filesDir, FILE_NAME)
                    .writeText("Thread: ${thread.name}\n\n${Log.getStackTraceString(error)}")
            }
            previous?.uncaughtException(thread, error)   // still let Android close the app as usual
        }
    }

    fun read(filesDir: File): String? =
        File(filesDir, FILE_NAME).takeIf { it.exists() }?.readText()

    fun clear(filesDir: File) {
        File(filesDir, FILE_NAME).delete()
    }
}

/**
 * The icon you tap. Plain Android views on purpose: if the editor (Hilt/Compose) crashes, this
 * screen still works. No crash on file -> opens the editor. Crash on file -> shows it, with a
 * Copy button.
 */
class LauncherActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = CrashLog.read(filesDir)
        if (crash == null) startEditor() else showCrash(crash)
    }

    private fun startEditor() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun showCrash(report: String) {
        val message = TextView(this).apply {
            text = report
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(32, 32, 32, 32)
        }
        val copy = Button(this).apply {
            text = "Copy error text"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Nova crash", report))
                Toast.makeText(this@LauncherActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        val retry = Button(this).apply {
            text = "Clear and try again"
            setOnClickListener {
                CrashLog.clear(filesDir)
                startEditor()
            }
        }
        val scroll = ScrollView(this).apply { addView(message) }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
            addView(copy)
            addView(retry)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(column)
    }
}
