package com.nova

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.nova.editor.EditorScreen
import com.nova.editor.ExoPreviewEngine
import com.nova.editor.PreviewEngine
import com.nova.music.AudiusProvider
import com.nova.music.HttpJson
import com.nova.music.JamendoProvider
import com.nova.music.MusicProvider
import com.nova.music.MusicRepository
import com.nova.music.SettingsStore
import com.nova.music.SoundCloudProvider
import com.nova.ui.NovaTheme
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient

/*
 * The small pieces that turn the loose files into a runnable app.
 * (Kotlin allows several top-level classes per file; split them up if you prefer.)
 */

/** Manifest: <application android:name=".NovaApp" ...>. Hilt generates the DI graph from this. */
@HiltAndroidApp
class NovaApp : android.app.Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        CrashLog.install(base.filesDir)      // before Hilt or anything else can crash
    }
}

/** Single-activity app: the whole UI is Compose. Opened by LauncherActivity (see CrashGuard.kt). */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NovaTheme {
                EditorScreen()   // its EditorViewModel is created by Hilt (hiltViewModel())
            }
        }
    }
}

/** Objects that live exactly as long as one editor session. */
@Module
@InstallIn(ViewModelComponent::class)
object EditorModule {

    /**
     * ViewModel-scoped, NOT singleton: EditorViewModel.onCleared() releases the players, so each
     * editor session needs a fresh engine. ExoPlayer must be created on the main thread, which is
     * where ViewModels are constructed.
     */
    @Provides
    @ViewModelScoped
    fun providePreviewEngine(@ApplicationContext context: Context): PreviewEngine =
        ExoPreviewEngine(context, CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate))
}

/** App-wide: networking, the music catalogues and the repository on top of them. */
@Module
@InstallIn(SingletonComponent::class)
object MusicModule {

    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder().build()

    @Provides
    @Singleton
    fun provideHttpJson(client: OkHttpClient): HttpJson = HttpJson(client)

    /** Add another catalogue by writing a MusicProvider and listing it here. Keys come from SettingsStore. */
    @Provides
    @Singleton
    fun provideProviders(http: HttpJson, settings: SettingsStore): List<MusicProvider> = listOf(
        JamendoProvider(http, settings),
        AudiusProvider(http, settings),
        SoundCloudProvider(http, settings),
    )

    @Provides
    @Singleton
    fun provideMusicRepository(
        @ApplicationContext context: Context,
        providers: List<@JvmSuppressWildcards MusicProvider>,
        client: OkHttpClient,
    ): MusicRepository = MusicRepository(context, providers, client)
}
