package com.nova

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import com.nova.editor.EditorScreen
import com.nova.editor.ExoPreviewEngine
import com.nova.editor.PreviewEngine
import com.nova.music.MusicProvider
import com.nova.music.MusicRepository
import com.nova.music.SoundCloudApi
import com.nova.music.SoundCloudProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import javax.inject.Singleton

/*
 * The three small pieces that turn the loose files into a runnable app.
 * (Kotlin allows several top-level classes per file; split them up if you prefer.)
 */

/** Manifest: <application android:name=".NovaApp" ...>. Hilt generates the DI graph from this. */
@HiltAndroidApp
class NovaApp : android.app.Application()

/** Single-activity app: the whole UI is Compose. Manifest: <activity android:name=".MainActivity" android:exported="true"> with the MAIN/LAUNCHER intent filter. */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                EditorScreen()   // its EditorViewModel is created by Hilt (hiltViewModel())
            }
        }
    }
}

/** Tells Hilt how to build the objects the ViewModel and repository need. */
@Module
@InstallIn(ViewModelComponent::class)
object EditorModule {

    /**
     * ViewModel-scoped, NOT singleton: EditorViewModel.onCleared() releases the player, so each
     * editor session needs a fresh one. ExoPlayer must be created on the main thread, which is
     * where ViewModels are constructed.
     */
    @Provides
    @ViewModelScoped
    fun providePreviewEngine(@ApplicationContext context: Context): PreviewEngine =
        ExoPreviewEngine(context, CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate))
}

@Module
@InstallIn(SingletonComponent::class)
object MusicModule {

    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        // TODO(auth): add an Interceptor that attaches a short-lived SoundCloud token fetched from
        // YOUR backend. Never put the client secret in the APK.
        .build()

    @Provides
    @Singleton
    fun provideSoundCloudApi(client: OkHttpClient): SoundCloudApi =
        Retrofit.Builder()
            .baseUrl("https://api.soundcloud.com/")            // confirm against SoundCloud's current API docs
            .client(client)
            .addConverterFactory(
                Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType())
            )
            .build()
            .create(SoundCloudApi::class.java)

    @Provides
    @Singleton
    fun provideProviders(soundCloud: SoundCloudApi): List<MusicProvider> =
        listOf(SoundCloudProvider(soundCloud))                 // add Jamendo/Audius/local providers here

    @Provides
    @Singleton
    fun provideMusicRepository(
        @ApplicationContext context: Context,
        providers: List<@JvmSuppressWildcards MusicProvider>,
        http: OkHttpClient,
    ): MusicRepository = MusicRepository(
        providers = providers,
        http = http,
        musicDir = java.io.File(context.filesDir, "music"),
    )
}
