package com.nova.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** One place for every colour, so the whole app can be re-skinned from here. */
object NovaColors {
    val Background = Color(0xFF0B0B0F)
    val Surface = Color(0xFF15151B)
    val SurfaceHigh = Color(0xFF22222B)
    val Accent = Color(0xFF2ED3C6)
    val OnAccent = Color(0xFF00201D)
    val TextPrimary = Color(0xFFF2F2F5)
    val TextSecondary = Color(0xFF9A9AA6)
    val VideoClip = Color(0xFF2B2B35)
    val AudioClip = Color(0xFF1C5E52)
    val Beat = Color(0xFFFFC857)
    val Danger = Color(0xFFFF6B6B)
}

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NovaColors.Accent,
            onPrimary = NovaColors.OnAccent,
            background = NovaColors.Background,
            onBackground = NovaColors.TextPrimary,
            surface = NovaColors.Surface,
            onSurface = NovaColors.TextPrimary,
            surfaceVariant = NovaColors.SurfaceHigh,
            onSurfaceVariant = NovaColors.TextSecondary,
            error = NovaColors.Danger,
        ),
        content = content,
    )
}
