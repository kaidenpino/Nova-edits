package com.nova.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.Effects
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.nova.editor.Clip
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Renders the timeline to an MP4 with Media3 Transformer (hardware MediaCodec encode).
 *
 *  - The video lane is a packed (gap-free) sequence, so what you previewed is what you get.
 *  - The music lane becomes a second, audio-only sequence; a leading gap (silence) positions a song that
 *    starts later in the video. Music is trimmed so it never runs past the end of the video.
 *  - The output frame size follows the first clip (long side capped at 1920), letterboxing the rest.
 *  - The result is saved to Movies/Nova in the gallery (Android 10+).
 *
 * Transformer must be created and driven from the main thread, which is where the ViewModel calls us.
 */
@Singleton
class NovaExporter @Inject constructor(@ApplicationContext private val context: Context) {

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var transformer: Transformer? = null
    private var progressTick: Runnable? = null
    private var cancelled = false

    /**
     * @param onProgress 0..1, on the main thread
     * @param onResult   success carries a human-readable "where it was saved"; on the main thread
     */
    fun start(
        videos: List<Clip>,
        audios: List<Clip>,
        onProgress: (Float) -> Unit,
        onResult: (Result<String>) -> Unit,
    ) {
        cancelled = false
        val composition = try {
            buildComposition(videos, audios)
        } catch (e: Exception) {
            onResult(Result.failure(e))
            return
        }

        val temp = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopProgress()
                    if (cancelled) { temp.delete(); return }
                    // Copying a large file into the gallery must not block the main thread.
                    io.execute {
                        val outcome = runCatching { saveToGallery(temp) }
                        temp.delete()
                        main.post { if (!cancelled) onResult(outcome) }
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    stopProgress()
                    temp.delete()
                    if (!cancelled) onResult(Result.failure(exportException))
                }
            })
            .build()

        transformer = t
        try {
            t.start(composition, temp.absolutePath)
        } catch (e: Exception) {
            temp.delete()
            onResult(Result.failure(e))
            return
        }
        startProgressPolling(t, onProgress)
    }

    fun cancel() {
        cancelled = true
        stopProgress()
        transformer?.cancel()
        transformer = null
    }

    /* ---------------------------- composition ---------------------------- */

    private fun buildComposition(videos: List<Clip>, audios: List<Clip>): Composition {
        require(videos.isNotEmpty()) { "Add a video first." }

        val videoSequence = EditedMediaItemSequence.Builder(videos.map { editedItem(it, removeVideo = false) }).build()
        val videoEndMs = videos.sumOf { it.durationMs }          // the video lane is packed: contiguous from 0

        val sequences = mutableListOf(videoSequence)

        val songs = audios.filter { it.timelineStartMs < videoEndMs }
        if (songs.isNotEmpty()) {
            val builder = EditedMediaItemSequence.Builder(emptyList<EditedMediaItem>())
            var cursorMs = 0L
            for (song in songs) {
                // Never let music run past the end of the video.
                val overshoot = max(0L, song.timelineEndMs - videoEndMs)
                val trimmed = song.copy(sourceOutMs = song.sourceOutMs - overshoot)
                val gapMs = trimmed.timelineStartMs - cursorMs
                if (gapMs > 0) builder.addGap(gapMs * 1000L)                 // microseconds of silence
                builder.addItem(editedItem(trimmed, removeVideo = true))
                cursorMs = trimmed.timelineEndMs
            }
            sequences += builder.build()
        }

        val (width, height) = outputSize(videos.first())
        val effects = Effects(
            emptyList(),
            listOf(Presentation.createForWidthAndHeight(width, height, Presentation.LAYOUT_SCALE_TO_FIT)),
        )
        return Composition.Builder(*sequences.toTypedArray()).setEffects(effects).build()
    }

    private fun editedItem(clip: Clip, removeVideo: Boolean): EditedMediaItem {
        val mediaItem = MediaItem.Builder()
            .setUri(clip.sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.sourceInMs)
                    .setEndPositionMs(clip.sourceOutMs)
                    .build()
            )
            .build()
        return EditedMediaItem.Builder(mediaItem).setRemoveVideo(removeVideo).build()
    }

    /** First clip's size (rotation already applied), long side capped at 1920, even numbers for H.264. */
    private fun outputSize(first: Clip): Pair<Int, Int> {
        if (first.videoWidth <= 0 || first.videoHeight <= 0) return 1280 to 720
        val scale = min(1f, 1920f / max(first.videoWidth, first.videoHeight))
        fun even(v: Float): Int = max(2, (v.roundToInt() / 2) * 2)
        return even(first.videoWidth * scale) to even(first.videoHeight * scale)
    }

    /* ---------------------------- progress / saving ---------------------------- */

    private fun startProgressPolling(t: Transformer, onProgress: (Float) -> Unit) {
        val holder = ProgressHolder()
        val tick = object : Runnable {
            override fun run() {
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    onProgress(holder.progress / 100f)
                }
                main.postDelayed(this, 300)
            }
        }
        progressTick = tick
        main.post(tick)
    }

    private fun stopProgress() {
        progressTick?.let { main.removeCallbacks(it) }
        progressTick = null
    }

    /** Copies the finished file into the gallery. Android 10+: Movies/Nova. Older: the app's own movies folder. */
    private fun saveToGallery(file: File): String {
        val name = "Nova_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Nova")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Couldn't create the video in your gallery")
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: throw IOException("Couldn't write the video")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return "Movies/Nova/$name"
        }

        // Android 8-9 can't write to the shared gallery without a storage permission; keep it in the app's folder.
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        val target = File(dir, name)
        file.copyTo(target, overwrite = true)
        return target.absolutePath
    }
}
