package com.nova.export

import com.nova.music.ExportRights
import com.nova.music.LocalAudio
import java.util.Locale

/* =====================================================================================
 *  EXPORT ENGINE: two interchangeable back ends behind one interface
 *
 *   1) Media3 Transformer  -> default: MediaCodec hardware encode, no GPL, battery-friendly
 *   2) FFmpeg              -> fallback for filters Transformer lacks (xfade, LUTs, ...)
 *
 *  NOTE: FFmpegKit was archived and its binaries retired in 2025. Do not depend on it directly.
 *  Use a maintained fork or your own LGPL build, and keep it behind FfmpegRunner so the
 *  choice stays swappable. Beware of GPL builds (libx264): they impose license obligations.
 * ===================================================================================== */

sealed interface ExportProgress {
    data class Running(val fraction: Float) : ExportProgress
    data class Done(val outputPath: String) : ExportProgress
    data class Failed(val message: String) : ExportProgress
}

interface FfmpegRunner {
    /** Executes ffmpeg with an argument list (NOT a shell string, so no quoting bugs). */
    suspend fun run(args: List<String>, onProgress: (timeMs: Long) -> Unit): Int   // exit code
}

/* =====================================================================================
 *  SPEC
 * ===================================================================================== */

/**
 * Takes the cached [LocalAudio] (not a bare path) so the licensing rule is enforced by the type
 * system: only tracks the repository cached as EXPORT_OK can ever reach the encoder. The repository
 * already refuses to cache PREVIEW_ONLY tracks; this `require` is the second, independent lock.
 */
data class MusicMix(
    val audio: LocalAudio,
    val startInSourceSec: Double = 0.0,  // trim: where to start inside the song
    val gainDb: Double = -8.0,           // music level relative to original
    val fadeInSec: Double = 1.0,
    val fadeOutSec: Double = 1.5,
    val duckUnderOriginal: Boolean = true, // lower the music while the clip's own audio is loud
) {
    init {
        require(audio.track.exportRights == ExportRights.EXPORT_OK) {
            "\"${audio.track.title}\" is preview-only and cannot be mixed into an export"
        }
    }

    val musicPath: String get() = audio.file.path

    /** Attribution to put in the export's description/credits (required by CC-BY and SoundCloud terms). */
    val creditLine: String
        get() = buildString {
            append('"').append(audio.track.title).append("\" by ").append(audio.track.artist)
            audio.track.license?.let { append(" [").append(it).append(']') }
            audio.track.permalinkUrl?.let { append(" - ").append(it) }
        }
}

data class ExportSpec(
    val videoPath: String,
    val outputPath: String,
    val durationSec: Double,             // length of the exported piece
    val videoHasAudio: Boolean,
    val music: MusicMix? = null,
    val videoFadeSec: Double = 0.5,      // fade from/to black
    val useHardwareEncoder: Boolean = true,
)

/* =====================================================================================
 *  COMMAND BUILDER
 *
 *  Produces (for a clip with audio, music, ducking, 12 s long):
 *
 *  ffmpeg -y -i clip.mp4 -ss 30.000 -t 12.000 -i song.mp3 \
 *    -filter_complex "
 *      [0:v]fade=t=in:st=0:d=0.5,fade=t=out:st=11.5:d=0.5[v];
 *      [1:a]afade=t=in:st=0:d=1.0,afade=t=out:st=10.5:d=1.5,volume=-8.0dB[m];
 *      [0:a]asplit=2[o1][o2];
 *      [m][o1]sidechaincompress=threshold=0.05:ratio=8:attack=20:release=300[md];
 *      [o2][md]amix=inputs=2:duration=first:dropout_transition=0[a]" \
 *    -map "[v]" -map "[a]" -t 12.000 \
 *    -c:v h264_mediacodec -b:v 12M -c:a aac -b:a 192k -movflags +faststart out.mp4
 *
 *  Notes:
 *   - Fading video requires re-encoding it; there is no lossless path with a fade.
 *   - `-ss`/`-t` BEFORE the music `-i` trims the song at input (fast, sample-accurate enough).
 *   - Fade-out start times are computed from the export duration.
 *   - `sidechaincompress` input order: [signal-to-compress][sidechain].
 *   - `amix` divides every input's level by the input count unless `normalize=0` (FFmpeg >= 4.4)
 *     is set; without it the whole mix comes out ~6 dB quieter than intended.
 * ===================================================================================== */

object FfmpegCommandBuilder {

    fun build(spec: ExportSpec): List<String> {
        val d = spec.durationSec
        val args = mutableListOf("-y", "-i", spec.videoPath)

        spec.music?.let { m ->
            args += listOf("-ss", sec(m.startInSourceSec), "-t", sec(d), "-i", m.musicPath)
        }

        // ---- Filter graph ----
        val graph = mutableListOf<String>()

        // Video: fade in from black and out to black.
        val vf = spec.videoFadeSec.coerceAtMost(d / 2)
        graph += "[0:v]fade=t=in:st=0:d=${sec(vf)},fade=t=out:st=${sec(d - vf)}:d=${sec(vf)}[v]"

        // Audio
        val audioLabel: String? = when {
            spec.music == null && spec.videoHasAudio -> "0:a"          // untouched original audio
            spec.music == null -> null                                  // silent video
            else -> {
                val m = requireNotNull(spec.music)   // non-null here: both null cases matched above
                val fin = m.fadeInSec.coerceAtMost(d / 2)
                val fout = m.fadeOutSec.coerceAtMost(d / 2)
                graph += "[1:a]afade=t=in:st=0:d=${sec(fin)}," +
                    "afade=t=out:st=${sec(d - fout)}:d=${sec(fout)}," +
                    "volume=${"%.1f".format(Locale.US, m.gainDb)}dB[m]"

                if (!spec.videoHasAudio) {
                    graph += "[m]anull[a]"                              // music only
                } else if (m.duckUnderOriginal) {
                    graph += "[0:a]asplit=2[o1][o2]"
                    graph += "[m][o1]sidechaincompress=threshold=0.05:ratio=8:attack=20:release=300[md]"
                    graph += "[o2][md]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]"
                } else {
                    graph += "[0:a][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]"
                }
                "[a]"
            }
        }

        args += listOf("-filter_complex", graph.joinToString(";"))
        args += listOf("-map", "[v]")
        audioLabel?.let { args += listOf("-map", it) }

        args += listOf("-t", sec(d))

        // ---- Encoders ----
        args += if (spec.useHardwareEncoder) {
            listOf("-c:v", "h264_mediacodec", "-b:v", "12M")            // availability depends on the FFmpeg build
        } else {
            listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "18")  // GPL build only
        }
        if (audioLabel != null) args += listOf("-c:a", "aac", "-b:a", "192k")
        args += listOf("-movflags", "+faststart", spec.outputPath)

        return args
    }

    private fun sec(v: Double) = String.format(Locale.US, "%.3f", v)
}

/* =====================================================================================
 *  FFmpeg-backed engine (progress via `-progress`/log parsing lives inside FfmpegRunner)
 * ===================================================================================== */

class FfmpegExportEngine(private val runner: FfmpegRunner) {

    suspend fun export(spec: ExportSpec, onProgress: (ExportProgress) -> Unit) {
        val args = FfmpegCommandBuilder.build(spec)
        val totalMs = (spec.durationSec * 1000).toLong()

        val exit = runner.run(args) { timeMs ->
            onProgress(ExportProgress.Running((timeMs.toFloat() / totalMs).coerceIn(0f, 1f)))
        }
        onProgress(
            if (exit == 0) ExportProgress.Done(spec.outputPath)
            else ExportProgress.Failed("ffmpeg exited with code $exit")
        )
    }
}

/* =====================================================================================
 *  RECOMMENDED PRIMARY PATH: Media3 Transformer (sketch)
 *
 *  Media3's Composition API changes between releases, so pin a version and check its docs.
 *  Shape of the solution:
 *
 *    val video = EditedMediaItem.Builder(
 *        MediaItem.Builder().setUri(videoUri)
 *            .setClippingConfiguration(ClippingConfiguration.Builder()
 *                .setStartPositionMs(inMs).setEndPositionMs(outMs).build())
 *            .build()
 *    ).setEffects(Effects(
 *        /* audio */ listOf(),
 *        /* video */ listOf(FadeToBlackEffect(...))         // custom GlEffect
 *    )).build()
 *
 *    val music = EditedMediaItem.Builder(MediaItem.fromUri(musicUri))
 *        .setRemoveVideo(true)
 *        .setEffects(Effects(listOf(GainRampAudioProcessor(fadeIn, fadeOut)), listOf()))
 *        .build()
 *
 *    val composition = Composition.Builder(listOf(
 *        EditedMediaItemSequence(listOf(video)),            // track 1: video (+ its audio)
 *        EditedMediaItemSequence(listOf(music)),            // track 2: music, mixed automatically
 *    )).build()
 *
 *    Transformer.Builder(context).addListener(listener).build().start(composition, outputPath)
 *
 *  Run inside a WorkManager foreground worker so long exports survive backgrounding.
 * ===================================================================================== */
