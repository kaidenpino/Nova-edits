# Nova: video editor (starter)

Kotlin + Jetpack Compose. See docs/ARCHITECTURE.md for the design.

- Build in the cloud from a phone: see PHONE-GUIDE.md (published alongside this zip).
- Build on a computer: open this folder in Android Studio (File -> Open), let Gradle sync, press Run.
- validation/ holds Python scripts that check the beat-detection, auto-cut and edit-operation logic.
