# Nova: video editor (v0.2)

Kotlin + Jetpack Compose. Design notes: docs/ARCHITECTURE.md. Phone build guide: PHONE-GUIDE.md.

- Build on a computer: open this folder in Android Studio (File -> Open), let Gradle sync, press Run.
- Build from a phone: upload this zip to a GitHub repo with .github/workflows/build.yml (see PHONE-GUIDE.md).
- validation/ holds Python scripts that check the beat-detection, auto-cut and edit-operation logic.

Source layout (app/src/main/java/com/nova):
  ui/      theme
  editor/  model, edit operations, preview engine (master clock), timeline UI, ViewModel, screen
  music/   catalogue providers, repository, music sheet
  export/  Media3 Transformer export
  beat/    tempo + beat-grid detection, auto-cut planner
